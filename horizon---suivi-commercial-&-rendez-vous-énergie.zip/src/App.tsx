import React, { useState, useEffect } from 'react';
import { Agent, Appointment, AppointmentStatus, SyncConfig } from './types';
import {
  isFictionalAgent,
  loadActiveUser,
  loadAgents,
  loadAppointments,
  loadSyncConfig,
  purgeLegacyStorage,
  pushAllAppointmentsToGoogleSheet,
  pushAppointmentToGoogleSheet,
  saveActiveUser,
  saveAgents,
  saveAppointments,
  saveSyncConfig,
} from './utils/storage';
import { INITIAL_AGENTS } from './data/mockData';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { AppointmentListView } from './components/AppointmentListView';
import { AppointmentForm } from './components/AppointmentForm';
import { CalendarView } from './components/CalendarView';
import { SyncConfigView } from './components/SyncConfigView';
import { TeamManagementView } from './components/TeamManagementView';
import { ShareModal } from './components/ShareModal';
import { AppointmentDetailModal } from './components/AppointmentDetailModal';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [agents, setAgents] = useState<Agent[]>(() => {
    purgeLegacyStorage();
    const list = loadAgents().filter((a) => !isFictionalAgent(a));
    const hasSophie = list.some((a) => a.name.toLowerCase().includes('sophie vaillant'));
    return hasSophie ? list : [INITIAL_AGENTS[0], ...list];
  });
  const [activeUser, setActiveUser] = useState<Agent>(() => {
    purgeLegacyStorage();
    const list = loadAgents().filter((a) => !isFictionalAgent(a));
    const sophie = list.find((a) => a.name.toLowerCase().includes('sophie vaillant'));
    return sophie || list[0] || INITIAL_AGENTS[0];
  });
  const [appointments, setAppointments] = useState<Appointment[]>(loadAppointments);
  const [syncConfig, setSyncConfig] = useState<SyncConfig>(loadSyncConfig);

  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const [isShareOpen, setIsShareOpen] = useState(false);

  // Global sync state
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncToast, setSyncToast] = useState<{ text: string; error?: boolean } | null>(null);

  // Ensure mock appointments and fictional agents are purged from state
  useEffect(() => {
    purgeLegacyStorage();
    setAppointments((prev) => prev.filter((a) => !/^rdv-10[1-9]$/.test(a.id)));
    setAgents((prev) => {
      const filtered = prev.filter((a) => !isFictionalAgent(a));
      const hasSophie = filtered.some((a) => a.name.toLowerCase().includes('sophie vaillant'));
      const result = hasSophie ? filtered : [INITIAL_AGENTS[0], ...filtered];
      saveAgents(result);
      return result;
    });
    setActiveUser((prev) => {
      if (isFictionalAgent(prev)) {
        return INITIAL_AGENTS[0];
      }
      return prev;
    });
  }, []);

  // Support URL parameters for role-based and commercial direct links
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const userParam = params.get('user') || params.get('agent');
      const roleParam = params.get('role');

      if (userParam) {
        const found = agents.find(
          (a) =>
            a.id === userParam ||
            a.name.toLowerCase().includes(userParam.toLowerCase()) ||
            a.email.toLowerCase() === userParam.toLowerCase()
        );
        if (found) {
          setActiveUser(found);
          saveActiveUser(found);
        }
      } else if (roleParam === 'agent' || roleParam === 'commercial') {
        const firstAgent = agents.find((a) => a.role === 'agent');
        if (firstAgent) {
          setActiveUser(firstAgent);
          saveActiveUser(firstAgent);
        }
      }
    }
  }, [agents]);

  // Protect sync tab: if non-administrator, redirect to dashboard
  useEffect(() => {
    if (activeUser.role !== 'administrateur' && currentTab === 'sync') {
      setCurrentTab('dashboard');
    }
  }, [activeUser, currentTab]);

  // Sync to localStorage
  useEffect(() => {
    saveAppointments(appointments);
  }, [appointments]);

  useEffect(() => {
    saveAgents(agents);
  }, [agents]);

  useEffect(() => {
    saveActiveUser(activeUser);
  }, [activeUser]);

  useEffect(() => {
    saveSyncConfig(syncConfig);
  }, [syncConfig]);

  const handleSaveAppointment = async (saved: Appointment, syncNow: boolean = true) => {
    setAppointments((prev) => {
      const exists = prev.some((a) => a.id === saved.id);
      if (exists) {
        return prev.map((a) => (a.id === saved.id ? saved : a));
      }
      return [saved, ...prev];
    });

    setEditingAppointment(null);
    setCurrentTab('list');

    // If sync configured and syncNow requested, push directly to Google Sheets
    if (syncNow && syncConfig.exec_url) {
      setIsSyncing(true);
      const assignedAgent = agents.find((a) => a.id === saved.agent_id);
      const res = await pushAppointmentToGoogleSheet(
        saved,
        syncConfig,
        assignedAgent?.name || 'Sophie Vaillant'
      );
      setIsSyncing(false);

      if (res.success) {
        setSyncToast({
          text: `Rendez-vous de ${saved.prospect_name} enregistré et synchronisé dans votre Google Sheet !`,
        });
        setTimeout(() => setSyncToast(null), 5000);
      } else {
        setSyncToast({
          text: `Rendez-vous enregistré localement, mais échec Google Sheets : ${res.error}`,
          error: true,
        });
        setTimeout(() => setSyncToast(null), 9000);
      }
    } else {
      setSyncToast({
        text: `Rendez-vous de ${saved.prospect_name} enregistré localement.`,
      });
      setTimeout(() => setSyncToast(null), 4000);
    }
  };

  const handleDeleteAppointment = (id: string) => {
    setAppointments((prev) => prev.filter((a) => a.id !== id));
    if (selectedAppointment?.id === id) {
      setSelectedAppointment(null);
    }
  };

  const handleUpdateStatus = (id: string, status: AppointmentStatus) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status, updated_at: new Date().toISOString() } : a))
    );
    if (selectedAppointment?.id === id) {
      setSelectedAppointment((prev) => (prev ? { ...prev, status } : null));
    }
  };

  const handleNewAppointmentClick = (prefillDate?: string) => {
    setEditingAppointment({
      id: '',
      prospect_name: '',
      phone: '',
      email: '',
      postal_code: '',
      city: '',
      address: '',
      project_type: 'panneaux photovoltaïques',
      date: prefillDate || new Date().toISOString().split('T')[0],
      time: '10:00',
      status: 'à confirmer',
      agent_id: activeUser.role === 'agent' ? activeUser.id : (agents[0]?.id || ''),
      comment: '',
      estimated_power: '6 kWc',
      current_heating: '',
      roof_orientation: 'Sud',
      created_at: '',
      updated_at: '',
    });
    setCurrentTab('new');
  };

  const handleStartEdit = (appointment: Appointment) => {
    setEditingAppointment(appointment);
    setCurrentTab('new');
  };

  // Agent / Admin Management Handlers
  const handleAddAgent = (newAgent: Agent) => {
    setAgents((prev) => [...prev, newAgent]);
  };

  const handleUpdateAgent = (updated: Agent) => {
    setAgents((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
    if (activeUser.id === updated.id) {
      setActiveUser(updated);
    }
  };

  const handleDeleteAgent = (id: string) => {
    setAgents((prev) => prev.filter((a) => a.id !== id));
    if (activeUser.id === id) {
      const fallback = agents.find((a) => a.id !== id) || agents[0];
      if (fallback) setActiveUser(fallback);
    }
  };

  // Push all appointments to Google Sheet via Apps Script Web App
  const handlePushAllToSheet = async () => {
    if (!syncConfig.exec_url) {
      setSyncToast({
        text: "Veuillez d'abord configurer l'URL Apps Script dans l'onglet Google Sheets.",
        error: true,
      });
      setCurrentTab('sync');
      return;
    }

    setIsSyncing(true);
    setSyncToast(null);

    const result = await pushAllAppointmentsToGoogleSheet(appointments, syncConfig);
    setIsSyncing(false);

    if (result.success) {
      setSyncToast({
        text: `Félicitations : ${result.count} rendez-vous ont été envoyés et enregistrés avec succès dans votre Google Sheet !`,
      });
      setTimeout(() => setSyncToast(null), 6000);
    } else {
      setSyncToast({
        text: `Échec d'envoi Google Sheets : ${result.error}`,
        error: true,
      });
      setTimeout(() => setSyncToast(null), 9000);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const countToday = appointments.filter(
    (a) =>
      a.date === todayStr &&
      (activeUser.role === 'administrateur' || a.agent_id === activeUser.id)
  ).length;

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F7F2]">
      {/* 3-zone Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          if (tab === 'new') {
            handleNewAppointmentClick();
          } else {
            setCurrentTab(tab);
          }
        }}
        activeUser={activeUser}
        agents={agents}
        onChangeUser={setActiveUser}
        onOpenShare={() => setIsShareOpen(true)}
        appointmentCountToday={countToday}
        onSyncAll={handlePushAllToSheet}
        isSyncing={isSyncing}
      />

      {/* Global Sync Notification Banner */}
      {syncToast && (
        <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-4">
          <div
            className={`p-4 rounded-xl border text-xs sm:text-sm font-semibold flex items-center justify-between shadow-sm animate-fadeIn ${
              syncToast.error
                ? 'bg-amber-50 border-amber-300 text-amber-950'
                : 'bg-emerald-50 border-emerald-300 text-emerald-950'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {syncToast.error ? (
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
              ) : (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              )}
              <span>{syncToast.text}</span>
            </div>
            <button
              onClick={() => setSyncToast(null)}
              className="text-xs text-slate-500 hover:text-slate-800 ml-3 underline"
            >
              Fermer
            </button>
          </div>
        </div>
      )}

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {currentTab === 'dashboard' && (
          <DashboardView
            appointments={appointments}
            agents={agents}
            activeUser={activeUser}
            onSelectAppointment={(item) => setSelectedAppointment(item)}
            onNewAppointment={() => handleNewAppointmentClick()}
            onUpdateStatus={handleUpdateStatus}
            onNavigateTab={setCurrentTab}
            onSyncAll={handlePushAllToSheet}
            isSyncing={isSyncing}
          />
        )}

        {currentTab === 'list' && (
          <AppointmentListView
            appointments={appointments}
            agents={agents}
            activeUser={activeUser}
            onSelectAppointment={(item) => setSelectedAppointment(item)}
            onNewAppointment={() => handleNewAppointmentClick()}
            onUpdateStatus={handleUpdateStatus}
            onDeleteAppointment={handleDeleteAppointment}
            onSyncAll={handlePushAllToSheet}
            isSyncing={isSyncing}
          />
        )}

        {currentTab === 'calendar' && (
          <CalendarView
            appointments={appointments}
            agents={agents}
            activeUser={activeUser}
            onSelectAppointment={(item) => setSelectedAppointment(item)}
            onNewAppointment={(date) => handleNewAppointmentClick(date)}
          />
        )}

        {currentTab === 'team' && (
          <TeamManagementView
            agents={agents}
            appointments={appointments}
            activeUser={activeUser}
            onAddAgent={handleAddAgent}
            onUpdateAgent={handleUpdateAgent}
            onDeleteAgent={handleDeleteAgent}
            onSwitchUser={setActiveUser}
          />
        )}

        {currentTab === 'new' && (
          <AppointmentForm
            initialAppointment={editingAppointment}
            agents={agents}
            activeUser={activeUser}
            existingAppointments={appointments}
            onSave={handleSaveAppointment}
            onCancel={() => {
              setEditingAppointment(null);
              setCurrentTab('dashboard');
            }}
          />
        )}

        {currentTab === 'sync' && (
          <SyncConfigView
            config={syncConfig}
            onUpdateConfig={setSyncConfig}
            appointments={appointments}
            agents={agents}
            onImportAppointments={(imported) => {
              setAppointments(imported);
              saveAppointments(imported);
            }}
            onSyncAll={handlePushAllToSheet}
            isSyncing={isSyncing}
            syncSuccessMessage={syncToast && !syncToast.error ? syncToast.text : null}
            syncErrorMessage={syncToast && syncToast.error ? syncToast.text : null}
          />
        )}
      </main>

      {/* Detail Modal */}
      <AppointmentDetailModal
        appointment={selectedAppointment}
        agents={agents}
        activeUser={activeUser}
        onClose={() => setSelectedAppointment(null)}
        onEdit={handleStartEdit}
        onUpdateStatus={handleUpdateStatus}
        onDelete={handleDeleteAppointment}
      />

      {/* Free Share & Publish Modal */}
      <ShareModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        appointments={appointments}
        agents={agents}
      />

      {/* Quiet Footer */}
      <footer className="border-t border-[#DBE4DC] bg-white py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-4 text-xs text-[#5E7368]">
          <div className="flex items-center gap-2">
            <span className="font-editorial font-bold text-[#14382F] text-sm">T2A ECOHABITAT</span>
            <span>·</span>
            <span>Directrice Commerciale : Sophie Vaillant</span>
            <span>·</span>
            <span>Équipe Solaire & Pompe à Chaleur</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsShareOpen(true)}
              className="text-[#14382F] hover:underline font-semibold"
            >
              Partager l'application
            </button>
            <span>·</span>
            <span>Version 2.1 Web & Mobile</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
