import React, { useState } from 'react';
import { Agent, Appointment, AppointmentStatus } from '../types';
import {
  Calendar,
  Clock,
  Edit2,
  ExternalLink,
  Flame,
  Home,
  Mail,
  MapPin,
  Phone,
  Sun,
  Trash2,
  User,
  X,
  Zap,
} from 'lucide-react';

import { isFictionalAgent } from '../utils/storage';

interface AppointmentDetailModalProps {
  appointment: Appointment | null;
  agents: Agent[];
  activeUser: Agent;
  onClose: () => void;
  onEdit: (appointment: Appointment) => void;
  onUpdateStatus: (id: string, status: AppointmentStatus) => void;
  onDelete: (id: string) => void;
}

export const AppointmentDetailModal: React.FC<AppointmentDetailModalProps> = ({
  appointment,
  agents,
  activeUser,
  onClose,
  onEdit,
  onUpdateStatus,
  onDelete,
}) => {
  const [confirmingDelete, setConfirmingDelete] = useState(false);

  if (!appointment) return null;

  const validAgents = agents.filter((a) => !isFictionalAgent(a));
  const agent = validAgents.find((a) => a.id === appointment.agent_id);
  const canEdit = activeUser.role === 'administrateur' || appointment.agent_id === activeUser.id;

  const mapsQuery = encodeURIComponent(
    `${appointment.address || ''} ${appointment.postal_code} ${appointment.city}`
  );

  const handleDelete = () => {
    onDelete(appointment.id);
    setConfirmingDelete(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-[#DBE4DC] shadow-2xl p-6 sm:p-8">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#DBE4DC] pb-4 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#5E7368]">
                Dossier Prospect
              </span>
              <span aria-hidden="true" className="text-[#B8CABE]">·</span>
              <span className="font-mono text-[11px] text-[#5E7368]">{appointment.id}</span>
            </div>
            <h2 className="font-editorial text-2xl font-bold text-[#14382F]">
              {appointment.prospect_name}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            title="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Date & Status Strip */}
        <div className="bg-[#FAFBF8] border border-[#DBE4DC] rounded-xl p-4 mb-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#14382F] text-white flex items-center justify-center font-bold">
              <Calendar className="w-5 h-5 text-[#C9882B]" />
            </div>
            <div>
              <div className="text-sm font-bold text-[#14382F]">
                {appointment.date} à {appointment.time}
              </div>
              <div className="text-xs text-[#5E7368]">
                Commercial : <strong>{agent?.name || 'Non attribué'}</strong>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="modal-status-select" className="sr-only">Statut du rendez-vous</label>
            <span className="text-xs text-[#5E7368] font-medium">Statut :</span>
            <select
              id="modal-status-select"
              aria-label="Statut du rendez-vous"
              value={appointment.status}
              onChange={(e) => onUpdateStatus(appointment.id, e.target.value as AppointmentStatus)}
              className="text-xs font-bold py-1.5 px-3 rounded-lg border border-[#B8CABE] bg-white cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#14382F]"
            >
              <option value="à confirmer">À confirmer</option>
              <option value="confirmé">Confirmé</option>
              <option value="réalisé">Réalisé</option>
              <option value="reporté">Reporté</option>
              <option value="annulé">Annulé</option>
            </select>
          </div>
        </div>

        {/* Contact info */}
        <div className="grid sm:grid-cols-2 gap-4 mb-6">
          <div className="p-4 rounded-xl border border-[#DBE4DC] bg-white">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#14382F] flex items-center gap-1.5 mb-2">
              <User className="w-3.5 h-3.5 text-[#C9882B]" />
              Coordonnées
            </h4>
            <div className="space-y-1.5 text-xs text-[#182B24]">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#5E7368]" />
                <a
                  href={`tel:${appointment.phone.replace(/\s+/g, '')}`}
                  className="font-bold text-[#14382F] hover:underline"
                >
                  {appointment.phone}
                </a>
              </div>
              {appointment.email && (
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-[#5E7368]" />
                  <a href={`mailto:${appointment.email}`} className="hover:underline">
                    {appointment.email}
                  </a>
                </div>
              )}
              <div className="flex items-start gap-2 pt-1">
                <MapPin className="w-3.5 h-3.5 text-[#C9882B] shrink-0 mt-0.5" />
                <div>
                  <div>{appointment.address || 'Adresse non renseignée'}</div>
                  <div className="font-semibold">{appointment.postal_code} {appointment.city}</div>
                </div>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-[#DBE4DC]">
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${mapsQuery}`}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-[#14382F] hover:underline flex items-center gap-1 font-semibold"
              >
                <ExternalLink className="w-3 h-3 text-[#C9882B]" />
                Ouvrir l'adresse dans Google Maps
              </a>
            </div>
          </div>

          {/* Energy Specs */}
          <div className="p-4 rounded-xl border border-[#DBE4DC] bg-white">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#14382F] flex items-center gap-1.5 mb-2">
              <Zap className="w-3.5 h-3.5 text-[#C9882B]" />
              Projet Énergétique
            </h4>
            <div className="space-y-2 text-xs text-[#182B24]">
              <div className="flex items-center justify-between border-b border-[#DBE4DC]/60 pb-1.5">
                <span className="text-[#5E7368]">Type d'installation :</span>
                <span className="font-bold capitalize flex items-center gap-1 text-[#14382F]">
                  {appointment.project_type.includes('solaire') ? (
                    <Sun className="w-3.5 h-3.5 text-amber-600" />
                  ) : (
                    <Flame className="w-3.5 h-3.5 text-blue-600" />
                  )}
                  {appointment.project_type}
                </span>
              </div>

              {appointment.estimated_power && (
                <div className="flex items-center justify-between border-b border-[#DBE4DC]/60 pb-1.5">
                  <span className="text-[#5E7368]">Puissance / Capacité :</span>
                  <span className="font-bold">{appointment.estimated_power}</span>
                </div>
              )}

              {appointment.current_heating && (
                <div className="flex items-center justify-between border-b border-[#DBE4DC]/60 pb-1.5">
                  <span className="text-[#5E7368]">Chauffage actuel :</span>
                  <span className="font-semibold">{appointment.current_heating}</span>
                </div>
              )}

              {appointment.roof_orientation && (
                <div className="flex items-center justify-between">
                  <span className="text-[#5E7368]">Orientation toiture :</span>
                  <span className="font-semibold">{appointment.roof_orientation}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Notes & Comments */}
        {appointment.comment && (
          <div className="mb-6 p-4 rounded-xl bg-[#F6F7F2] border border-[#DBE4DC]">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#14382F] mb-1.5">
              Notes de qualification & contraintes
            </h4>
            <p className="text-xs text-[#182B24] leading-relaxed whitespace-pre-wrap">
              {appointment.comment}
            </p>
          </div>
        )}

        {/* Footer actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-[#DBE4DC]">
          <div>
            {!confirmingDelete ? (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="px-3.5 py-2 text-xs font-bold text-red-600 hover:text-red-800 hover:bg-red-50 border border-red-200 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Supprimer ce rendez-vous"
              >
                <Trash2 className="w-4 h-4 text-red-600" />
                <span>Supprimer le rendez-vous</span>
              </button>
            ) : (
              <div className="flex items-center gap-2 bg-red-50 p-1.5 rounded-xl border border-red-200 animate-fadeIn">
                <span className="text-xs font-bold text-red-900 px-1">Confirmer ?</span>
                <button
                  type="button"
                  onClick={handleDelete}
                  className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                >
                  Oui, supprimer
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmingDelete(false)}
                  className="px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Annuler
                </button>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-[#B8CABE] text-[#14382F] rounded-xl text-xs font-semibold hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Fermer
            </button>

            {canEdit && (
              <button
                onClick={() => {
                  onEdit(appointment);
                  onClose();
                }}
                className="px-4 py-2 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" />
                Modifier la fiche
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
