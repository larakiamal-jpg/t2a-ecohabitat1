import React, { useState, useEffect } from 'react';
import { Agent, Appointment, ProjectType, AppointmentStatus } from '../types';
import {
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Clock,
  Flame,
  Home,
  Mail,
  MapPin,
  Phone,
  Sun,
  User,
  X,
  Zap,
} from 'lucide-react';
import { findPotentialDuplicates, isFictionalAgent } from '../utils/storage';

interface AppointmentFormProps {
  initialAppointment?: Appointment | null;
  agents: Agent[];
  activeUser: Agent;
  existingAppointments: Appointment[];
  onSave: (appointment: Appointment, syncDirectly?: boolean) => void;
  onCancel: () => void;
}

export const AppointmentForm: React.FC<AppointmentFormProps> = ({
  initialAppointment,
  agents,
  activeUser,
  existingAppointments,
  onSave,
  onCancel,
}) => {
  const isEditing = Boolean(initialAppointment?.id);
  const validAgents = agents.filter((a) => !isFictionalAgent(a));
  const [syncToSheet, setSyncToSheet] = useState(true);

  const [formData, setFormData] = useState<Partial<Appointment>>({
    prospect_name: '',
    phone: '',
    email: '',
    postal_code: '',
    city: '',
    address: '',
    project_type: 'panneaux photovoltaïques',
    date: new Date().toISOString().split('T')[0],
    time: '10:00',
    status: 'à confirmer',
    agent_id: activeUser.role === 'agent' ? activeUser.id : (validAgents[0]?.id || ''),
    comment: '',
    current_heating: '',
    estimated_power: '6 kWc',
    roof_orientation: 'Sud',
    source: 'Saisie directe',
  });

  const [overrideDuplicate, setOverrideDuplicate] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<{
    isDuplicate: boolean;
    reasons: string[];
    matches: Appointment[];
  }>({ isDuplicate: false, reasons: [], matches: [] });

  useEffect(() => {
    if (initialAppointment) {
      setFormData(initialAppointment);
    }
  }, [initialAppointment]);

  // Run duplicate & collision detector
  useEffect(() => {
    if (overrideDuplicate) return;

    const check = findPotentialDuplicates(
      formData,
      existingAppointments,
      initialAppointment?.id
    );
    setDuplicateWarning(check);
  }, [
    formData.phone,
    formData.agent_id,
    formData.date,
    formData.time,
    existingAppointments,
    initialAppointment?.id,
    overrideDuplicate,
  ]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setOverrideDuplicate(false); // Reset override on modification
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.prospect_name || !formData.phone || !formData.city || !formData.date || !formData.time) {
      alert('Veuillez remplir tous les champs obligatoires (*).');
      return;
    }

    // If duplicate detected and not overridden, alert user
    if (duplicateWarning.isDuplicate && !overrideDuplicate) {
      // Show warning block
      return;
    }

    const now = new Date().toISOString();
    const finalAppointment: Appointment = {
      id: initialAppointment?.id || `rdv-${Date.now().toString(36)}`,
      prospect_name: formData.prospect_name.trim(),
      phone: formData.phone.trim(),
      email: (formData.email || '').trim(),
      postal_code: formData.postal_code?.trim() || '',
      city: formData.city.trim(),
      address: formData.address?.trim() || '',
      project_type: (formData.project_type as ProjectType) || 'panneaux photovoltaïques',
      date: formData.date || '',
      time: formData.time || '10:00',
      status: (formData.status as AppointmentStatus) || 'à confirmer',
      agent_id: formData.agent_id || activeUser.id,
      comment: formData.comment?.trim() || '',
      current_heating: formData.current_heating?.trim() || '',
      estimated_power: formData.estimated_power?.trim() || '',
      roof_orientation: formData.roof_orientation?.trim() || '',
      source: formData.source || 'Saisie directe',
      created_at: initialAppointment?.created_at || now,
      updated_at: now,
    };

    onSave(finalAppointment, syncToSheet);
  };

  return (
    <div className="max-w-4xl mx-auto animate-fadeIn">
      <div className="bg-white border border-[#DBE4DC] rounded-2xl shadow-sm p-6 sm:p-8">
        <div className="flex items-center justify-between border-b border-[#DBE4DC] pb-4 mb-6">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#5E7368] block">
              {isEditing ? 'Édition de fiche' : 'Nouvelle prise de contact'}
            </span>
            <h1 className="font-editorial text-2xl font-bold text-[#14382F] mt-0.5">
              {isEditing ? `Modifier le rendez-vous de ${formData.prospect_name}` : 'Enregistrer un rendez-vous commercial'}
            </h1>
          </div>
          <button
            onClick={onCancel}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            title="Annuler"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Section 1: Informations Prospect */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#14382F] flex items-center gap-1.5 mb-3">
              <User className="w-3.5 h-3.5 text-[#C9882B]" />
              Coordonnées du prospect
            </h3>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Nom et prénom du prospect *
                </label>
                <input
                  type="text"
                  name="prospect_name"
                  required
                  placeholder="ex: Jean-Luc Moreau"
                  value={formData.prospect_name || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-[#5E7368]" />
                  Téléphone mobile / fixe *
                </label>
                <input
                  type="tel"
                  name="phone"
                  required
                  placeholder="ex: 06 14 25 36 47"
                  value={formData.phone || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1 flex items-center gap-1">
                  <Mail className="w-3 h-3 text-[#5E7368]" />
                  Adresse email
                </label>
                <input
                  type="email"
                  name="email"
                  placeholder="ex: jl.moreau@orange.fr"
                  value={formData.email || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#5E7368]" />
                  Ville *
                </label>
                <input
                  type="text"
                  name="city"
                  required
                  placeholder="ex: Nantes"
                  value={formData.city || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Code postal *
                </label>
                <input
                  type="text"
                  name="postal_code"
                  required
                  placeholder="ex: 44000"
                  value={formData.postal_code || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1 flex items-center gap-1">
                  <Home className="w-3 h-3 text-[#5E7368]" />
                  Adresse postale (Rue / Numéro)
                </label>
                <input
                  type="text"
                  name="address"
                  placeholder="ex: 14 Rue Crébillon"
                  value={formData.address || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Projet Énergie */}
          <div className="pt-4 border-t border-[#DBE4DC]">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#14382F] flex items-center gap-1.5 mb-3">
              <Zap className="w-3.5 h-3.5 text-[#C9882B]" />
              Qualification technique de l’installation
            </h3>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Type de projet *
                </label>
                <select
                  name="project_type"
                  value={formData.project_type}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                >
                  <option value="panneaux photovoltaïques">Panneaux photovoltaïques</option>
                  <option value="pompe à chaleur">Pompe à chaleur</option>
                  <option value="système solaire combiné">Système solaire combiné</option>
                  <option value="rénovation globale">Rénovation globale</option>
                  <option value="autre">Autre solution</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1 flex items-center gap-1">
                  <Flame className="w-3 h-3 text-[#5E7368]" />
                  Chauffage actuel
                </label>
                <select
                  name="current_heating"
                  value={formData.current_heating || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                >
                  <option value="">Sélectionner</option>
                  <option value="Fioul">Chaudière Fioul</option>
                  <option value="Gaz">Gaz (naturel ou propane)</option>
                  <option value="Électrique direct">Convecteurs électriques</option>
                  <option value="Bois / Pellets">Poêle bois / pellets</option>
                  <option value="Autre">Autre</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1 flex items-center gap-1">
                  <Sun className="w-3 h-3 text-[#5E7368]" />
                  Puissance visée / Surface
                </label>
                <input
                  type="text"
                  name="estimated_power"
                  placeholder="ex: 3 kWc, 6 kWc, 9 kWc"
                  value={formData.estimated_power || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Orientation toiture
                </label>
                <select
                  name="roof_orientation"
                  value={formData.roof_orientation || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                >
                  <option value="">Sélectionner</option>
                  <option value="Sud">Plein Sud</option>
                  <option value="Sud-Est">Sud-Est</option>
                  <option value="Sud-Ouest">Sud-Ouest</option>
                  <option value="Est-Ouest">Est-Ouest (double pan)</option>
                  <option value="Toit plat">Toit terrasse plat</option>
                  <option value="Autre">Autre</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Planning & Attribution */}
          <div className="pt-4 border-t border-[#DBE4DC]">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#14382F] flex items-center gap-1.5 mb-3">
              <Calendar className="w-3.5 h-3.5 text-[#C9882B]" />
              Date, horaire & Commercial responsable
            </h3>

            <div className="grid sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1 flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-[#5E7368]" />
                  Date du rendez-vous *
                </label>
                <input
                  type="date"
                  name="date"
                  required
                  value={formData.date || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-[#5E7368]" />
                  Heure *
                </label>
                <input
                  type="time"
                  name="time"
                  required
                  value={formData.time || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Agent commercial responsable *
                </label>
                <select
                  name="agent_id"
                  required
                  value={formData.agent_id || ''}
                  onChange={handleChange}
                  disabled={activeUser.role === 'agent'}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F] disabled:opacity-75"
                >
                  {validAgents.map((agent) => (
                    <option key={agent.id} value={agent.id}>
                      {agent.name} ({agent.role === 'administrateur' ? 'Directeur' : 'Commercial'})
                    </option>
                  ))}
                </select>
                {activeUser.role === 'agent' && (
                  <span className="text-[10px] text-[#5E7368] mt-1 block">
                    Attribué automatiquement à votre compte.
                  </span>
                )}
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 mt-4">
              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Statut du dossier *
                </label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                >
                  <option value="à confirmer">À confirmer (rappel requis)</option>
                  <option value="confirmé">Confirmé (visite planifiée)</option>
                  <option value="réalisé">Réalisé (visite effectuée)</option>
                  <option value="reporté">Reporté</option>
                  <option value="annulé">Annulé</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Origine du lead
                </label>
                <input
                  type="text"
                  name="source"
                  placeholder="ex: Formulaire Web, Parrainage, Salon de l’habitat"
                  value={formData.source || ''}
                  onChange={handleChange}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Commentaires & Notes */}
          <div className="pt-4 border-t border-[#DBE4DC]">
            <label className="block text-xs font-bold text-[#182B24] mb-1">
              Commentaires, contraintes techniques et notes de qualification
            </label>
            <textarea
              name="comment"
              rows={3}
              placeholder="ex: Toiture ardoise 30°, compteur Linky triphasé, facture électricité actuelle ~2200€/an. Le prospect souhaite une étude avant fin du mois."
              value={formData.comment || ''}
              onChange={handleChange}
              className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg p-3 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
            />
          </div>

          {/* Interactive Duplicate / Collision Warning */}
          {duplicateWarning.isDuplicate && !overrideDuplicate && (
            <div className="p-4 rounded-xl border border-amber-300 bg-amber-50 text-amber-950 animate-fadeIn">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1.5 flex-1">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900">
                    Alerte : Doublon ou conflit d'horaire détecté
                  </h4>
                  <ul className="text-xs text-amber-900 list-disc pl-4 space-y-0.5">
                    {duplicateWarning.reasons.map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                  <p className="text-[11px] text-amber-800 pt-1">
                    Vous pouvez ajuster l’horaire ou valider l’enregistrement si ce doublon est volontaire.
                  </p>
                  <div className="flex items-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setOverrideDuplicate(true)}
                      className="px-3 py-1.5 bg-[#14382F] text-white rounded-lg text-xs font-semibold hover:bg-[#0D2620] transition-colors"
                    >
                      Poursuivre quand même l’enregistrement
                    </button>
                    <button
                      type="button"
                      onClick={onCancel}
                      className="px-3 py-1.5 border border-amber-300 hover:bg-amber-100 text-amber-900 rounded-lg text-xs font-semibold transition-colors"
                    >
                      Annuler
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Synchronisation immédiate checkbox */}
          <div className="pt-2 flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-[#14382F] font-medium">
              <input
                type="checkbox"
                checked={syncToSheet}
                onChange={(e) => setSyncToSheet(e.target.checked)}
                className="w-4 h-4 rounded border-[#B8CABE] text-[#14382F] focus:ring-[#14382F] accent-[#14382F]"
              />
              <span>Pousser directement vers Google Sheets après enregistrement</span>
            </label>
            <span className="text-[11px] text-[#5E7368]">
              {syncToSheet ? '● Synchronisation active' : '○ Enregistrement local seul'}
            </span>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#DBE4DC]">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-[#B8CABE] text-[#14382F] hover:bg-slate-50 rounded-xl text-xs font-semibold transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C9882B]"
            >
              <CheckCircle2 className="w-4 h-4 text-[#C9882B]" />
              <span>{isEditing ? 'Enregistrer les modifications' : 'Créer le rendez-vous'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
