import React, { useState, useMemo } from 'react';
import { Agent, Appointment, AppointmentStatus, ProjectType } from '../types';
import {
  AlertCircle,
  AlertTriangle,
  Calendar,
  Clock,
  Download,
  Edit2,
  ExternalLink,
  Filter,
  Flame,
  LayoutGrid,
  List,
  MapPin,
  Phone,
  PlusCircle,
  Search,
  Send,
  Sun,
  Trash2,
  User,
  X,
  Zap,
} from 'lucide-react';
import { exportToCSV, isFictionalAgent } from '../utils/storage';

interface AppointmentListViewProps {
  appointments: Appointment[];
  agents: Agent[];
  activeUser: Agent;
  onSelectAppointment: (appointment: Appointment) => void;
  onNewAppointment: () => void;
  onUpdateStatus: (id: string, status: AppointmentStatus) => void;
  onDeleteAppointment: (id: string) => void;
  onSyncAll?: () => void;
  isSyncing?: boolean;
}

export const AppointmentListView: React.FC<AppointmentListViewProps> = ({
  appointments,
  agents,
  activeUser,
  onSelectAppointment,
  onNewAppointment,
  onUpdateStatus,
  onDeleteAppointment,
  onSyncAll,
  isSyncing = false,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [agentFilter, setAgentFilter] = useState<string>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [periodFilter, setPeriodFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  // Inline delete confirmation state (safe in iframe, no window.confirm)
  const [appointmentToDelete, setAppointmentToDelete] = useState<Appointment | null>(null);

  const validAgents = useMemo(() => agents.filter((a) => !isFictionalAgent(a)), [agents]);
  const agentMap = useMemo(() => new Map(validAgents.map((a) => [a.id, a])), [validAgents]);
  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);

  // Filter logic
  const filteredAppointments = useMemo(() => {
    return appointments
      .filter((item) => {
        // Text search
        if (search) {
          const q = search.toLowerCase();
          const match =
            item.prospect_name.toLowerCase().includes(q) ||
            item.city.toLowerCase().includes(q) ||
            item.postal_code.includes(q) ||
            item.phone.includes(q) ||
            (item.comment || '').toLowerCase().includes(q);
          if (!match) return false;
        }

        // Status
        if (statusFilter !== 'all' && item.status !== statusFilter) return false;

        // Agent
        if (agentFilter !== 'all' && item.agent_id !== agentFilter) return false;

        // Project
        if (projectFilter !== 'all' && item.project_type !== projectFilter) return false;

        // Period
        if (periodFilter === 'today' && item.date !== todayStr) return false;
        if (periodFilter === 'upcoming' && item.date < todayStr) return false;
        if (periodFilter === 'past' && item.date >= todayStr) return false;

        return true;
      })
      .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  }, [appointments, search, statusFilter, agentFilter, projectFilter, periodFilter, todayStr]);

  const confirmDelete = () => {
    if (appointmentToDelete) {
      onDeleteAppointment(appointmentToDelete.id);
      setAppointmentToDelete(null);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white border border-[#DBE4DC] rounded-2xl p-6 shadow-sm">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#5E7368] block">
            Suivi Opérationnel
          </span>
          <h1 className="font-editorial text-2xl font-bold text-[#14382F] mt-0.5">
            Liste des rendez-vous ({filteredAppointments.length})
          </h1>
          <p className="text-xs text-[#5E7368] mt-1">
            Consultez, modifiez, supprimez et synchronisez vos visites techniques de faisabilité énergétique.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {onSyncAll && (
            <button
              onClick={onSyncAll}
              disabled={isSyncing}
              className="px-4 py-2 bg-[#C9882B] hover:bg-[#b57723] text-[#14382F] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm disabled:opacity-50"
              title="Envoyer tous les rendez-vous vers votre classeur Google Sheet"
            >
              <Send className={`w-3.5 h-3.5 ${isSyncing ? 'animate-bounce' : ''}`} />
              <span>{isSyncing ? 'Envoi en cours...' : 'Pousser vers le Sheet'}</span>
            </button>
          )}

          {appointments.length > 0 && (
            <button
              onClick={() => exportToCSV(filteredAppointments, agents)}
              className="px-3 py-2 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="Exporter les rendez-vous affichés en CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          )}

          <button
            onClick={onNewAppointment}
            className="px-4 py-2 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition-colors"
          >
            <PlusCircle className="w-4 h-4 text-[#C9882B]" />
            <span>Nouveau RDV</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      {appointments.length > 0 && (
        <div className="bg-white border border-[#DBE4DC] rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {/* Search box */}
            <div className="relative sm:col-span-2 lg:col-span-1">
              <Search className="w-4 h-4 text-[#5E7368] absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Nom, ville, code postal..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-[#FAFBF8] border border-[#B8CABE] rounded-lg text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
              />
            </div>

            {/* Status */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full py-2 px-3 bg-[#FAFBF8] border border-[#B8CABE] rounded-lg text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
              >
                <option value="all">Tous les statuts</option>
                <option value="à confirmer">À confirmer</option>
                <option value="confirmé">Confirmé</option>
                <option value="réalisé">Réalisé</option>
                <option value="reporté">Reporté</option>
                <option value="annulé">Annulé</option>
              </select>
            </div>

            {/* Agent */}
            <div>
              <select
                value={agentFilter}
                onChange={(e) => setAgentFilter(e.target.value)}
                className="w-full py-2 px-3 bg-[#FAFBF8] border border-[#B8CABE] rounded-lg text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
              >
                <option value="all">Tous les commerciaux</option>
                {validAgents.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Project Type */}
            <div>
              <select
                value={projectFilter}
                onChange={(e) => setProjectFilter(e.target.value)}
                className="w-full py-2 px-3 bg-[#FAFBF8] border border-[#B8CABE] rounded-lg text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
              >
                <option value="all">Toutes énergies</option>
                <option value="panneaux photovoltaïques">Photovoltaïque</option>
                <option value="pompe à chaleur">Pompe à chaleur</option>
                <option value="système solaire combiné">Solaire combiné</option>
                <option value="rénovation globale">Rénovation globale</option>
              </select>
            </div>

            {/* Period */}
            <div>
              <select
                value={periodFilter}
                onChange={(e) => setPeriodFilter(e.target.value)}
                className="w-full py-2 px-3 bg-[#FAFBF8] border border-[#B8CABE] rounded-lg text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
              >
                <option value="all">Toutes les dates</option>
                <option value="today">Aujourd’hui</option>
                <option value="upcoming">À venir</option>
                <option value="past">Passés</option>
              </select>
            </div>
          </div>

          {/* View mode toggle & reset */}
          <div className="flex items-center justify-between text-xs pt-3 border-t border-[#DBE4DC]">
            <div className="flex items-center gap-2 text-[#5E7368]">
              <Filter className="w-3.5 h-3.5" />
              <span>{filteredAppointments.length} résultat(s)</span>
              {(search || statusFilter !== 'all' || agentFilter !== 'all' || projectFilter !== 'all' || periodFilter !== 'all') && (
                <button
                  onClick={() => {
                    setSearch('');
                    setStatusFilter('all');
                    setAgentFilter('all');
                    setProjectFilter('all');
                    setPeriodFilter('all');
                  }}
                  className="text-[#C9882B] hover:underline font-semibold ml-2 cursor-pointer"
                >
                  Réinitialiser les filtres
                </button>
              )}
            </div>

            <div className="flex items-center gap-1 bg-[#F6F7F2] p-1 rounded-lg border border-[#DBE4DC]">
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded cursor-pointer ${
                  viewMode === 'table' ? 'bg-white shadow-xs text-[#14382F]' : 'text-[#5E7368]'
                }`}
                title="Vue Tableau compacte"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('cards')}
                className={`p-1.5 rounded cursor-pointer ${
                  viewMode === 'cards' ? 'bg-white shadow-xs text-[#14382F]' : 'text-[#5E7368]'
                }`}
                title="Vue Cartes détaillées"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Appointment Data Display */}
      {filteredAppointments.length === 0 ? (
        <div className="text-center py-16 bg-white border border-[#DBE4DC] rounded-2xl p-6 shadow-sm">
          <Calendar className="w-12 h-12 text-[#96B8A7] mx-auto mb-3" />
          <h3 className="text-base font-bold text-[#14382F]">
            {appointments.length === 0
              ? 'Aucun rendez-vous enregistré pour le moment'
              : 'Aucun rendez-vous ne correspond à vos filtres'}
          </h3>
          <p className="text-xs text-[#5E7368] mt-1 max-w-sm mx-auto">
            {appointments.length === 0
              ? 'La base est propre et prête pour vos premières saisies réelles sur le terrain.'
              : 'Essayez de réinitialiser vos critères de recherche.'}
          </p>
          <button
            onClick={onNewAppointment}
            className="mt-4 px-4 py-2 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-[#C9882B]" />
            <span>Enregistrer un premier rendez-vous</span>
          </button>
        </div>
      ) : viewMode === 'table' ? (
        /* High-Density Table View */
        <div className="bg-white border border-[#DBE4DC] rounded-2xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#FAFBF8] border-b border-[#DBE4DC] text-[#5E7368] uppercase tracking-wider font-semibold">
                  <th className="py-3.5 px-4">Date & Heure</th>
                  <th className="py-3.5 px-4">Prospect</th>
                  <th className="py-3.5 px-4">Localisation</th>
                  <th className="py-3.5 px-4">Projet & Puissance</th>
                  <th className="py-3.5 px-4">Commercial</th>
                  <th className="py-3.5 px-4">Statut</th>
                  <th className="py-3.5 px-4 text-right">Actions (Supprimer / Modifier)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#DBE4DC]">
                {filteredAppointments.map((item) => {
                  const assignedAgent = agentMap.get(item.agent_id);
                  const isToday = item.date === todayStr;

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-[#F6F7F2]/80 transition-colors ${
                        isToday ? 'bg-[#EDF1EA]/30' : ''
                      }`}
                    >
                      {/* Date & Time */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="font-semibold text-[#14382F] flex items-center gap-1.5 font-editorial text-sm">
                          {item.time}
                          {isToday && (
                            <span className="text-[10px] bg-[#C9882B] text-[#14382F] font-bold px-1.5 py-0.2 rounded font-sans">
                              Auj.
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-[#5E7368]">{item.date}</div>
                      </td>

                      {/* Prospect */}
                      <td className="py-3.5 px-4">
                        <button
                          onClick={() => onSelectAppointment(item)}
                          className="font-bold text-[#14382F] hover:underline text-left block cursor-pointer"
                        >
                          {item.prospect_name}
                        </button>
                        <div className="flex items-center gap-1.5 text-[11px] text-[#5E7368] mt-0.5">
                          <a
                            href={`tel:${item.phone.replace(/\s+/g, '')}`}
                            className="hover:text-[#14382F] hover:underline"
                          >
                            {item.phone}
                          </a>
                        </div>
                      </td>

                      {/* City */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1 text-[#182B24]">
                          <MapPin className="w-3 h-3 text-[#C9882B]" />
                          <span>{item.city}</span>
                        </div>
                        <div className="text-[11px] text-[#5E7368]">{item.postal_code}</div>
                      </td>

                      {/* Project Type */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 font-medium text-[#14382F]">
                          {item.project_type.includes('solaire') || item.project_type.includes('photo') ? (
                            <Sun className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          ) : (
                            <Flame className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                          )}
                          <span className="capitalize">{item.project_type}</span>
                        </div>
                        {item.estimated_power && (
                          <div className="text-[11px] text-[#5E7368]">
                            Capacité : {item.estimated_power}
                          </div>
                        )}
                      </td>

                      {/* Commercial */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <div
                            className="w-2.5 h-2.5 rounded-full shrink-0"
                            style={{ backgroundColor: assignedAgent?.color || '#5E7368' }}
                          />
                          <span className="text-[#182B24] font-medium">
                            {assignedAgent?.name || 'Non attribué'}
                          </span>
                        </div>
                      </td>

                      {/* Status Dropdown */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <select
                          value={item.status}
                          onChange={(e) =>
                            onUpdateStatus(item.id, e.target.value as AppointmentStatus)
                          }
                          className={`text-[11px] font-bold py-1 px-2.5 rounded-full border cursor-pointer focus:outline-none ${
                            item.status === 'confirmé'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : item.status === 'à confirmer'
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : item.status === 'réalisé'
                              ? 'bg-blue-50 text-blue-800 border-blue-200'
                              : item.status === 'reporté'
                              ? 'bg-purple-50 text-purple-800 border-purple-200'
                              : 'bg-slate-100 text-slate-700 border-slate-300'
                          }`}
                        >
                          <option value="à confirmer">À confirmer</option>
                          <option value="confirmé">Confirmé</option>
                          <option value="réalisé">Réalisé</option>
                          <option value="reporté">Reporté</option>
                          <option value="annulé">Annulé</option>
                        </select>
                      </td>

                      {/* Action buttons (TRASH / EDIT / MAP) */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-2">
                          {/* Map directions */}
                          {item.city && (
                            <a
                              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                                `${item.address || ''} ${item.postal_code} ${item.city}`
                              )}`}
                              target="_blank"
                              rel="noreferrer"
                              className="p-2 text-slate-500 hover:text-[#14382F] hover:bg-slate-100 rounded-lg transition-colors"
                              title="Ouvrir itinéraire GPS"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          )}

                          {/* Edit button */}
                          <button
                            onClick={() => onSelectAppointment(item)}
                            className="p-2 text-slate-600 hover:text-[#14382F] hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            title="Modifier la fiche"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          {/* Accessible TRASH CORBEILLE button */}
                          <button
                            onClick={() => setAppointmentToDelete(item)}
                            className="p-2 text-red-600 hover:text-red-800 hover:bg-red-50 border border-red-200/80 rounded-lg transition-all shadow-xs cursor-pointer flex items-center gap-1"
                            title={`Supprimer définitivement le rendez-vous de ${item.prospect_name}`}
                            aria-label={`Supprimer le rendez-vous de ${item.prospect_name}`}
                          >
                            <Trash2 className="w-4 h-4 text-red-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Card Grid View */
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAppointments.map((item) => {
            const assignedAgent = agentMap.get(item.agent_id);
            return (
              <div
                key={item.id}
                className="bg-white border border-[#DBE4DC] hover:border-[#14382F]/40 rounded-2xl p-5 shadow-sm transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-3">
                    <span className="font-editorial text-sm font-bold text-[#14382F]">
                      {item.date} · {item.time}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        item.status === 'confirmé'
                          ? 'bg-emerald-100 text-emerald-800'
                          : item.status === 'à confirmer'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-[#182B24] mb-1">
                    {item.prospect_name}
                  </h3>

                  <div className="space-y-1 text-xs text-[#5E7368] mb-3">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#C9882B]" />
                      <span>{item.city} ({item.postal_code})</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-[#5E7368]" />
                      <span>{item.phone}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-medium text-[#14382F]">
                      <Zap className="w-3.5 h-3.5 text-[#C9882B]" />
                      <span className="capitalize">{item.project_type}</span>
                    </div>
                  </div>

                  {item.comment && (
                    <p className="text-xs text-[#5E7368] italic line-clamp-2 bg-[#F6F7F2] p-2 rounded-lg">
                      « {item.comment} »
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between pt-4 mt-4 border-t border-[#DBE4DC]">
                  <span className="text-[11px] text-[#5E7368]">
                    Agent : <strong>{assignedAgent?.name || 'Inconnu'}</strong>
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setAppointmentToDelete(item)}
                      className="p-1.5 text-red-600 hover:text-red-800 hover:bg-red-50 border border-red-200 rounded-lg transition-colors cursor-pointer"
                      title="Supprimer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onSelectAppointment(item)}
                      className="px-3 py-1.5 bg-[#14382F] text-white rounded-lg text-xs font-semibold hover:bg-[#0D2620] transition-colors cursor-pointer"
                    >
                      Détails
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Safe In-App Delete Confirmation Modal (NO window.confirm!) */}
      {appointmentToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full border border-red-200 shadow-2xl p-6">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-red-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-editorial text-lg font-bold text-[#14382F]">
                  Supprimer ce rendez-vous ?
                </h3>
                <p className="text-xs text-[#5E7368] mt-1 leading-relaxed">
                  Êtes-vous sûr de vouloir supprimer définitivement le rendez-vous de{' '}
                  <strong className="text-slate-900">{appointmentToDelete.prospect_name}</strong>{' '}
                  ({appointmentToDelete.city}) prévu le{' '}
                  <span className="font-semibold text-slate-800">
                    {appointmentToDelete.date} à {appointmentToDelete.time}
                  </span>{' '}
                  ?
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-[#DBE4DC]">
              <button
                type="button"
                onClick={() => setAppointmentToDelete(null)}
                className="px-4 py-2 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Oui, supprimer</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
