import React, { useState, useMemo } from 'react';
import { Agent, Appointment } from '../types';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, MapPin, User, Sun, Flame } from 'lucide-react';
import { isFictionalAgent } from '../utils/storage';

interface CalendarViewProps {
  appointments: Appointment[];
  agents: Agent[];
  activeUser: Agent;
  onSelectAppointment: (appointment: Appointment) => void;
  onNewAppointment: (date?: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  appointments,
  agents,
  activeUser,
  onSelectAppointment,
  onNewAppointment,
}) => {
  const [currentWeekOffset, setCurrentWeekOffset] = useState(0);
  const validAgents = useMemo(() => agents.filter((a) => !isFictionalAgent(a)), [agents]);
  const agentMap = useMemo(() => new Map(validAgents.map((a) => [a.id, a])), [validAgents]);

  // Compute days of the current viewed week (Monday to Saturday)
  const weekDays = useMemo(() => {
    const today = new Date();
    // Monday of current week
    const currentDay = today.getDay(); // 0 is Sunday, 1 is Monday
    const distanceToMonday = currentDay === 0 ? -6 : 1 - currentDay;
    const monday = new Date(today);
    monday.setDate(today.getDate() + distanceToMonday + currentWeekOffset * 7);

    const days = [];
    for (let i = 0; i < 6; i++) {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      const iso = d.toISOString().split('T')[0];
      const label = new Intl.DateTimeFormat('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' }).format(d);
      days.push({ date: iso, label, isToday: iso === new Date().toISOString().split('T')[0] });
    }
    return days;
  }, [currentWeekOffset]);

  const appointmentsByDate = useMemo(() => {
    const map = new Map<string, Appointment[]>();
    for (const a of appointments) {
      if (activeUser.role === 'agent' && a.agent_id !== activeUser.id) continue;
      const list = map.get(a.date) || [];
      list.push(a);
      map.set(a.date, list);
    }
    // Sort each day's appointments by time
    map.forEach((list) => list.sort((a, b) => a.time.localeCompare(b.time)));
    return map;
  }, [appointments, activeUser]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Bar with week pagination */}
      <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#5E7368] block">
            Planification Commerciale
          </span>
          <h1 className="font-editorial text-2xl font-bold text-[#14382F] mt-0.5">
            Agenda hebdomadaire des visites
          </h1>
          <p className="text-xs text-[#5E7368] mt-1">
            Visualisez les créneaux d'intervention des commerciaux sur le terrain.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentWeekOffset((prev) => prev - 1)}
            className="p-2 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-lg text-xs font-semibold flex items-center transition-colors"
            title="Semaine précédente"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={() => setCurrentWeekOffset(0)}
            className="px-3 py-2 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-lg text-xs font-semibold transition-colors"
          >
            Aujourd’hui
          </button>

          <button
            onClick={() => setCurrentWeekOffset((prev) => prev + 1)}
            className="p-2 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-lg text-xs font-semibold flex items-center transition-colors"
            title="Semaine suivante"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grid of 6 days (Lundi -> Samedi) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {weekDays.map((day) => {
          const list = appointmentsByDate.get(day.date) || [];

          return (
            <div
              key={day.date}
              className={`bg-white border rounded-2xl flex flex-col min-h-[440px] shadow-sm overflow-hidden transition-all ${
                day.isToday ? 'border-[#14382F] ring-1 ring-[#14382F]' : 'border-[#DBE4DC]'
              }`}
            >
              {/* Day Header */}
              <div
                className={`p-3.5 border-b text-center ${
                  day.isToday ? 'bg-[#14382F] text-white' : 'bg-[#FAFBF8] border-[#DBE4DC] text-[#182B24]'
                }`}
              >
                <div className="font-editorial text-sm font-bold capitalize">
                  {day.label}
                </div>
                <div
                  className={`text-[10px] mt-0.5 font-medium ${
                    day.isToday ? 'text-[#96B8A7]' : 'text-[#5E7368]'
                  }`}
                >
                  {list.length} rendez-vous
                </div>
              </div>

              {/* Day Body with slot items */}
              <div className="p-2.5 flex-1 space-y-2 overflow-y-auto">
                {list.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center p-3 text-center">
                    <p className="text-[11px] text-[#5E7368] mb-2">Créneaux libres</p>
                    <button
                      onClick={() => onNewAppointment(day.date)}
                      className="px-2.5 py-1 text-[11px] font-semibold text-[#14382F] hover:bg-[#F6F7F2] border border-[#DBE4DC] rounded-md transition-colors"
                    >
                      + Planifier
                    </button>
                  </div>
                ) : (
                  list.map((item) => {
                    const assignedAgent = agentMap.get(item.agent_id);

                    return (
                      <div
                        key={item.id}
                        onClick={() => onSelectAppointment(item)}
                        className="p-2.5 rounded-xl border border-[#DBE4DC] hover:border-[#14382F] bg-[#FAFBF8] cursor-pointer transition-all hover:shadow-xs group"
                      >
                        <div className="flex items-center justify-between text-[11px] mb-1 font-editorial font-bold text-[#14382F]">
                          <span>{item.time}</span>
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded-full uppercase tracking-wider ${
                              item.status === 'confirmé'
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.status === 'à confirmer'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {item.status.slice(0, 7)}
                          </span>
                        </div>

                        <div className="font-bold text-xs text-[#182B24] truncate group-hover:text-[#14382F]">
                          {item.prospect_name}
                        </div>

                        <div className="flex items-center gap-1 text-[10px] text-[#5E7368] mt-1">
                          <MapPin className="w-3 h-3 text-[#C9882B] shrink-0" />
                          <span className="truncate">{item.city}</span>
                        </div>

                        <div className="flex items-center justify-between text-[10px] text-[#5E7368] mt-1.5 pt-1.5 border-t border-[#DBE4DC]/60">
                          <span className="flex items-center gap-1 font-medium text-[#182B24] truncate">
                            {item.project_type.includes('solaire') ? (
                              <Sun className="w-3 h-3 text-amber-600 shrink-0" />
                            ) : (
                              <Flame className="w-3 h-3 text-blue-600 shrink-0" />
                            )}
                            <span className="truncate">
                              {item.project_type.includes('solaire') ? 'Solaire' : 'PAC'}
                            </span>
                          </span>

                          {assignedAgent && (
                            <span
                              className="w-2 h-2 rounded-full shrink-0"
                              style={{ backgroundColor: assignedAgent.color }}
                              title={`Agent : ${assignedAgent.name}`}
                            />
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
