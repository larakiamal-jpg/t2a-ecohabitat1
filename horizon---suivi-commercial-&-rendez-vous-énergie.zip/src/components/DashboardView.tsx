import React, { useMemo } from 'react';
import { Agent, Appointment } from '../types';
import {
  Calendar,
  CheckCircle2,
  Clock,
  MapPin,
  Phone,
  PlusCircle,
  Sun,
  Flame,
  Zap,
  ArrowRight,
  TrendingUp,
  Send,
} from 'lucide-react';
import { isFictionalAgent } from '../utils/storage';

interface DashboardViewProps {
  appointments: Appointment[];
  agents: Agent[];
  activeUser: Agent;
  onSelectAppointment: (appointment: Appointment) => void;
  onNewAppointment: () => void;
  onUpdateStatus: (id: string, status: Appointment['status']) => void;
  onNavigateTab: (tab: string) => void;
  onSyncAll?: () => void;
  isSyncing?: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  appointments,
  agents,
  activeUser,
  onSelectAppointment,
  onNewAppointment,
  onUpdateStatus,
  onNavigateTab,
  onSyncAll,
  isSyncing = false,
}) => {
  const validAgents = useMemo(() => agents.filter((a) => !isFictionalAgent(a)), [agents]);
  const agentMap = useMemo(() => new Map(validAgents.map((a) => [a.id, a])), [validAgents]);

  // Role filtering: Admin sees all, agent can filter or see personal
  const visibleAppointments =
    activeUser.role === 'administrateur'
      ? appointments
      : appointments.filter((a) => a.agent_id === activeUser.id);

  const todayStr = new Date().toISOString().split('T')[0];

  const todayList = visibleAppointments
    .filter((a) => a.date === todayStr)
    .sort((a, b) => a.time.localeCompare(b.time));

  const upcomingList = visibleAppointments
    .filter((a) => a.date > todayStr && a.status !== 'annulé')
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));

  const completedCount = visibleAppointments.filter((a) => a.status === 'réalisé').length;
  const confirmedCount = visibleAppointments.filter((a) => a.status === 'confirmé').length;
  const totalCount = visibleAppointments.length;
  const confirmationRate = totalCount > 0 ? Math.round((confirmedCount / totalCount) * 100) : 0;

  // Breakdown by energy type
  const solarCount = visibleAppointments.filter(
    (a) => a.project_type === 'panneaux photovoltaïques' || a.project_type === 'système solaire combiné'
  ).length;
  const pacCount = visibleAppointments.filter((a) => a.project_type === 'pompe à chaleur').length;
  const otherCount = totalCount - (solarCount + pacCount);

  const formattedToday = new Intl.DateTimeFormat('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Banner / Hero Kicker */}
      <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 sm:p-8 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#5E7368]">
              <span>Suivi Commercial Énergie</span>
              <span aria-hidden="true">·</span>
              <span className="capitalize">{formattedToday}</span>
              <span aria-hidden="true">·</span>
              <span className="text-[#14382F] font-semibold">
                {activeUser.role === 'administrateur' ? 'Vue Globale Équipe' : `Espace ${activeUser.name}`}
              </span>
            </div>
            <h1 className="font-editorial text-2xl sm:text-3xl font-bold text-[#14382F] mt-2">
              Tableau de bord commercial
            </h1>
            <p className="text-sm text-[#5E7368] mt-1 max-w-2xl">
              Gestion centralisée des prospects, des créneaux de visite technique et de la qualification des projets solaires & pompes à chaleur.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {onSyncAll && (
              <button
                onClick={onSyncAll}
                disabled={isSyncing}
                className="px-4 py-2.5 bg-[#C9882B] hover:bg-[#b57723] text-[#14382F] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm disabled:opacity-50 whitespace-nowrap"
                title="Pousser les rendez-vous vers votre classeur Google Sheet"
              >
                <Send className={`w-3.5 h-3.5 ${isSyncing ? 'animate-bounce' : ''}`} />
                <span>{isSyncing ? 'Envoi en cours...' : 'Pousser vers le Sheet'}</span>
              </button>
            )}
            <button
              onClick={onNewAppointment}
              className="px-4 py-2.5 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C9882B]"
            >
              <PlusCircle className="w-4 h-4 text-[#C9882B]" />
              <span>Nouveau rendez-vous</span>
            </button>
            <button
              onClick={() => onNavigateTab('list')}
              className="px-4 py-2.5 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <span>Voir la liste ({totalCount})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 4 KPIs Strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8 pt-6 border-t border-[#DBE4DC]">
          <div className="p-4 rounded-xl bg-[#F6F7F2] border border-[#DBE4DC]/70">
            <div className="flex items-center justify-between text-xs text-[#5E7368]">
              <span className="font-medium">Rendez-vous aujourd’hui</span>
              <Clock className="w-4 h-4 text-[#C9882B]" />
            </div>
            <div className="text-2xl font-bold font-editorial text-[#14382F] mt-2 tabular-nums">
              {todayList.length}
            </div>
            <div className="text-[11px] text-[#5E7368] mt-1">
              {todayList.filter((a) => a.status === 'confirmé').length} confirmés sur le terrain
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#F6F7F2] border border-[#DBE4DC]/70">
            <div className="flex items-center justify-between text-xs text-[#5E7368]">
              <span className="font-medium">À venir (7 jours)</span>
              <Calendar className="w-4 h-4 text-[#14382F]" />
            </div>
            <div className="text-2xl font-bold font-editorial text-[#14382F] mt-2 tabular-nums">
              {upcomingList.length}
            </div>
            <div className="text-[11px] text-[#5E7368] mt-1">
              Planning en cours de remplissage
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#F6F7F2] border border-[#DBE4DC]/70">
            <div className="flex items-center justify-between text-xs text-[#5E7368]">
              <span className="font-medium">Taux de confirmation</span>
              <TrendingUp className="w-4 h-4 text-emerald-700" />
            </div>
            <div className="text-2xl font-bold font-editorial text-[#14382F] mt-2 tabular-nums">
              {confirmationRate}%
            </div>
            <div className="text-[11px] text-[#5E7368] mt-1">
              {confirmedCount} dossiers confirmés
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#F6F7F2] border border-[#DBE4DC]/70">
            <div className="flex items-center justify-between text-xs text-[#5E7368]">
              <span className="font-medium">Réalisés & Clôturés</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-700" />
            </div>
            <div className="text-2xl font-bold font-editorial text-[#14382F] mt-2 tabular-nums">
              {completedCount}
            </div>
            <div className="text-[11px] text-[#5E7368] mt-1">
              Visites techniques exécutées
            </div>
          </div>
        </div>
      </div>

      {/* Main 2-Column Split: Today's Agenda vs Upcoming & Energy Breakdown */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column (2 spans): Today's Schedule Focus */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 sm:p-7 shadow-sm">
            <div className="flex items-center justify-between border-b border-[#DBE4DC] pb-4 mb-6">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#5E7368] block">
                  Planning d’intervention
                </span>
                <h2 className="font-editorial text-xl font-bold text-[#14382F] mt-0.5">
                  Rendez-vous du jour ({todayList.length})
                </h2>
              </div>
              <span className="text-xs font-semibold text-[#14382F] bg-[#EDF1EA] px-3 py-1 rounded-full">
                Aujourd’hui
              </span>
            </div>

            {todayList.length === 0 ? (
              <div className="text-center py-12 px-4 border border-dashed border-[#DBE4DC] rounded-xl bg-[#F6F7F2]">
                <Calendar className="w-10 h-10 text-[#96B8A7] mx-auto mb-3" />
                <h3 className="text-sm font-bold text-[#14382F]">
                  Aucun rendez-vous planifié aujourd’hui
                </h3>
                <p className="text-xs text-[#5E7368] mt-1 max-w-sm mx-auto">
                  Votre agenda est libre pour la journée ou tous vos prospects sont programmés sur les jours suivants.
                </p>
                <button
                  onClick={onNewAppointment}
                  className="mt-4 px-3.5 py-1.5 bg-[#14382F] text-white rounded-lg text-xs font-semibold hover:bg-[#0D2620] transition-colors"
                >
                  Ajouter un créneau aujourd'hui
                </button>
              </div>
            ) : (
              <div className="space-y-3.5">
                {todayList.map((item) => {
                  const assignedAgent = agentMap.get(item.agent_id);
                  return (
                    <div
                      key={item.id}
                      className="p-4 sm:p-5 rounded-xl border border-[#DBE4DC] hover:border-[#14382F]/50 transition-all bg-[#FAFBF8] flex flex-wrap items-center justify-between gap-4"
                    >
                      <div className="space-y-1.5 min-w-[240px]">
                        <div className="flex items-center gap-2">
                          <span className="text-base font-bold font-editorial text-[#14382F]">
                            {item.time}
                          </span>
                          <span aria-hidden="true" className="text-[#B8CABE]">·</span>
                          <span className="text-sm font-bold text-[#182B24]">
                            {item.prospect_name}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                              item.status === 'confirmé'
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.status === 'à confirmer'
                                ? 'bg-amber-100 text-amber-800'
                                : item.status === 'réalisé'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {item.status}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#5E7368]">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-[#C9882B]" />
                            {item.city} ({item.postal_code})
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="flex items-center gap-1 font-medium text-[#14382F]">
                            {item.project_type.includes('solaire') || item.project_type.includes('photo') ? (
                              <Sun className="w-3.5 h-3.5 text-amber-600" />
                            ) : (
                              <Flame className="w-3.5 h-3.5 text-blue-600" />
                            )}
                            {item.project_type}
                          </span>
                          {assignedAgent && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>Agent : <strong className="text-slate-800">{assignedAgent.name}</strong></span>
                            </>
                          )}
                        </div>

                        {item.comment && (
                          <p className="text-xs text-[#5E7368] line-clamp-1 italic pt-1">
                            « {item.comment} »
                          </p>
                        )}
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-2 shrink-0">
                        {item.phone && (
                          <a
                            href={`tel:${item.phone.replace(/\s+/g, '')}`}
                            className="p-2 border border-[#B8CABE] rounded-lg hover:bg-slate-100 text-[#14382F] transition-colors"
                            title={`Appeler ${item.phone}`}
                          >
                            <Phone className="w-4 h-4" />
                          </a>
                        )}

                        {item.status === 'à confirmer' && (
                          <button
                            onClick={() => onUpdateStatus(item.id, 'confirmé')}
                            className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-colors"
                          >
                            Confirmer
                          </button>
                        )}

                        <button
                          onClick={() => onSelectAppointment(item)}
                          className="px-3 py-1.5 border border-[#14382F] text-[#14382F] hover:bg-[#14382F] hover:text-white rounded-lg text-xs font-semibold transition-colors"
                        >
                          Fiche détail
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Upcoming Highlights & Project Mix */}
        <div className="space-y-6">
          {/* Energy Mix Breakdown */}
          <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 shadow-sm">
            <h3 className="font-editorial text-lg font-bold text-[#14382F] mb-1">
              Mix Projets Énergétiques
            </h3>
            <p className="text-xs text-[#5E7368] mb-4">
              Répartition des demandes de transition énergétique en cours.
            </p>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="flex items-center gap-1.5 text-amber-800">
                    <Sun className="w-3.5 h-3.5" />
                    Solaire Photovoltaïque & Combiné
                  </span>
                  <span className="font-mono font-bold">{solarCount} ({totalCount > 0 ? Math.round((solarCount / totalCount) * 100) : 0}%)</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full transition-all"
                    style={{ width: `${totalCount > 0 ? (solarCount / totalCount) * 100 : 0}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="flex items-center gap-1.5 text-blue-800">
                    <Flame className="w-3.5 h-3.5" />
                    Pompe à Chaleur (Air/Eau & Air/Air)
                  </span>
                  <span className="font-mono font-bold">{pacCount} ({totalCount > 0 ? Math.round((pacCount / totalCount) * 100) : 0}%)</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full bg-blue-600 rounded-full transition-all"
                    style={{ width: `${totalCount > 0 ? (pacCount / totalCount) * 100 : 0}%` }}
                  />
                </div>
              </div>

              {otherCount > 0 && (
                <div>
                  <div className="flex justify-between text-xs font-medium mb-1">
                    <span className="text-emerald-800">Rénovation globale & autres</span>
                    <span className="font-mono font-bold">{otherCount}</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full bg-emerald-600 rounded-full transition-all"
                      style={{ width: `${totalCount > 0 ? (otherCount / totalCount) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Prochains RDV */}
          <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-editorial text-lg font-bold text-[#14382F]">
                À venir cette semaine
              </h3>
              <button
                onClick={() => onNavigateTab('list')}
                className="text-xs text-[#C9882B] hover:underline font-semibold"
              >
                Tous ({upcomingList.length})
              </button>
            </div>

            {upcomingList.length === 0 ? (
              <p className="text-xs text-[#5E7368] py-4 text-center">
                Aucun rendez-vous prévu pour les prochains jours.
              </p>
            ) : (
              <div className="divide-y divide-[#DBE4DC]">
                {upcomingList.slice(0, 4).map((item) => (
                  <div
                    key={item.id}
                    onClick={() => onSelectAppointment(item)}
                    className="py-3 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-50 px-2 rounded-lg transition-colors"
                  >
                    <div>
                      <div className="text-xs font-bold text-[#14382F]">
                        {item.prospect_name}
                      </div>
                      <div className="text-[11px] text-[#5E7368] flex items-center gap-1.5 mt-0.5">
                        <span>{item.date} à {item.time}</span>
                        <span>·</span>
                        <span>{item.city}</span>
                      </div>
                    </div>
                    <span className="text-[10px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                      {item.project_type.includes('solaire') ? 'Solaire' : 'PAC'}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
