import React, { useMemo } from 'react';
import { Agent } from '../types';
import {
  Calendar,
  CheckCircle2,
  FileSpreadsheet,
  Layers,
  PlusCircle,
  Send,
  Share2,
  Shield,
  User,
  Users,
  Zap,
} from 'lucide-react';
import { isFictionalAgent } from '../utils/storage';

interface HeaderProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  activeUser: Agent;
  agents: Agent[];
  onChangeUser: (agent: Agent) => void;
  onOpenShare: () => void;
  appointmentCountToday: number;
  onSyncAll?: () => void;
  isSyncing?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  activeUser,
  agents,
  onChangeUser,
  onOpenShare,
  appointmentCountToday,
  onSyncAll,
  isSyncing = false,
}) => {
  const validAgents = useMemo(() => agents.filter((a) => !isFictionalAgent(a)), [agents]);
  return (
    <header className="sticky top-0 z-30 bg-[#14382F] text-white border-b border-[#0D2620] shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4 sm:gap-8">
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onSelectTab('dashboard')}
              className="flex items-center gap-2.5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C9882B] rounded"
            >
              <div className="w-9 h-9 rounded-lg bg-[#C9882B] flex items-center justify-center text-[#14382F] font-bold shadow-sm">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <span className="font-editorial text-lg sm:text-xl font-bold tracking-tight text-white block leading-none">
                  T2A ECOHABITAT
                </span>
                <span className="text-[10px] tracking-wider uppercase text-[#96B8A7] block mt-0.5">
                  Éco-Habitat & Énergie Solaire
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links (single line, no wrap) */}
          <nav className="hidden md:flex items-center gap-1 shrink-0" aria-label="Navigation">
            <button
              onClick={() => onSelectTab('dashboard')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                currentTab === 'dashboard'
                  ? 'bg-white/15 text-white'
                  : 'text-[#D2E4D6] hover:text-white hover:bg-white/10'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Tableau de bord
              {appointmentCountToday > 0 && (
                <span className="ml-1 px-1.5 py-0.2 rounded-full bg-[#C9882B] text-[#14382F] text-[10px] font-bold">
                  {appointmentCountToday}
                </span>
              )}
            </button>

            <button
              onClick={() => onSelectTab('list')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                currentTab === 'list'
                  ? 'bg-white/15 text-white'
                  : 'text-[#D2E4D6] hover:text-white hover:bg-white/10'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Rendez-vous
            </button>

            <button
              onClick={() => onSelectTab('calendar')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                currentTab === 'calendar'
                  ? 'bg-white/15 text-white'
                  : 'text-[#D2E4D6] hover:text-white hover:bg-white/10'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              Agenda
            </button>

            <button
              onClick={() => onSelectTab('team')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                currentTab === 'team'
                  ? 'bg-white/15 text-white'
                  : 'text-[#D2E4D6] hover:text-white hover:bg-white/10'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Équipe & Rôles
            </button>

            <button
              onClick={() => onSelectTab('new')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                currentTab === 'new'
                  ? 'bg-white/15 text-white'
                  : 'text-[#D2E4D6] hover:text-white hover:bg-white/10'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5 text-[#C9882B]" />
              Nouveau RDV
            </button>

            {/* Onglet Google Sheets réservé exclusivement aux Administrateurs */}
            {activeUser.role === 'administrateur' && (
              <button
                onClick={() => onSelectTab('sync')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                  currentTab === 'sync'
                    ? 'bg-white/15 text-white'
                    : 'text-[#D2E4D6] hover:text-white hover:bg-white/10'
                }`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-[#C9882B]" />
                <span>Google Sheets</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block ml-0.5 animate-pulse" title="Google Sheet lié"></span>
              </button>
            )}
          </nav>

          {/* Zone 3: Actions, Sync, User Switcher & Share Button */}
          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
            {/* Quick Pousser vers Sheet Button (Uniquement visible par l'administrateur) */}
            {onSyncAll && activeUser.role === 'administrateur' && (
              <button
                onClick={onSyncAll}
                disabled={isSyncing}
                title="Pousser instantanément tous les rendez-vous vers votre Google Sheet"
                className="px-2.5 sm:px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-800/90 hover:bg-emerald-700 text-emerald-100 border border-emerald-500/40 transition-all flex items-center gap-1.5 shadow-xs whitespace-nowrap shrink-0 disabled:opacity-50 cursor-pointer"
              >
                <Send className={`w-3.5 h-3.5 text-[#C9882B] ${isSyncing ? 'animate-bounce' : ''}`} />
                <span className="hidden lg:inline">{isSyncing ? 'Envoi...' : 'Pousser vers le Sheet'}</span>
                <span className="lg:hidden">{isSyncing ? '...' : 'Pousser Sheet'}</span>
              </button>
            )}

            {/* User Profile Badge & Switcher */}
            <div className="relative">
              {activeUser.role === 'administrateur' ? (
                <div className="flex items-center gap-2 bg-[#0D2620]/60 border border-white/10 rounded-lg px-2.5 py-1 text-xs">
                  <Shield className="w-3.5 h-3.5 text-[#C9882B]" />
                  <label htmlFor="user-select-top" className="sr-only">Profil utilisateur actif</label>
                  <select
                    id="user-select-top"
                    aria-label="Profil utilisateur actif"
                    value={activeUser.id}
                    onChange={(e) => {
                      const selected = validAgents.find((a) => a.id === e.target.value);
                      if (selected) onChangeUser(selected);
                    }}
                    className="bg-transparent text-white text-xs font-medium focus:outline-none cursor-pointer pr-1"
                  >
                    {validAgents.map((agent) => (
                      <option key={agent.id} value={agent.id} className="text-[#182B24] bg-white">
                        {agent.name} ({agent.role === 'administrateur' ? 'Admin' : 'Commercial'})
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div className="flex items-center gap-2 bg-[#0D2620]/80 border border-emerald-500/30 rounded-lg px-3 py-1 text-xs text-white">
                  <User className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-semibold">{activeUser.name}</span>
                  <span className="text-[10px] bg-emerald-900/90 text-emerald-300 px-1.5 py-0.2 rounded font-bold">
                    Commercial
                  </span>
                </div>
              )}
            </div>

            {/* Share / Publish Button */}
            <button
              onClick={onOpenShare}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#C9882B] hover:bg-[#b57723] text-[#14382F] transition-colors flex items-center gap-1.5 shadow-sm whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Partager</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center gap-1 overflow-x-auto py-2.5 border-t border-white/10 text-xs">
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`px-3 py-1.5 rounded whitespace-nowrap shrink-0 ${
              currentTab === 'dashboard' ? 'bg-white/20 font-bold' : 'text-[#D2E4D6]'
            }`}
          >
            Tableau de bord
          </button>
          <button
            onClick={() => onSelectTab('list')}
            className={`px-3 py-1.5 rounded whitespace-nowrap shrink-0 ${
              currentTab === 'list' ? 'bg-white/20 font-bold' : 'text-[#D2E4D6]'
            }`}
          >
            Rendez-vous
          </button>
          <button
            onClick={() => onSelectTab('calendar')}
            className={`px-3 py-1.5 rounded whitespace-nowrap shrink-0 ${
              currentTab === 'calendar' ? 'bg-white/20 font-bold' : 'text-[#D2E4D6]'
            }`}
          >
            Agenda
          </button>
          <button
            onClick={() => onSelectTab('team')}
            className={`px-3 py-1.5 rounded whitespace-nowrap shrink-0 ${
              currentTab === 'team' ? 'bg-white/20 font-bold' : 'text-[#D2E4D6]'
            }`}
          >
            Équipe
          </button>
          <button
            onClick={() => onSelectTab('new')}
            className={`px-3 py-1.5 rounded whitespace-nowrap shrink-0 ${
              currentTab === 'new' ? 'bg-white/20 font-bold text-[#C9882B]' : 'text-[#D2E4D6]'
            }`}
          >
            + Nouveau RDV
          </button>
          {activeUser.role === 'administrateur' && (
            <button
              onClick={() => onSelectTab('sync')}
              className={`px-3 py-1.5 rounded whitespace-nowrap shrink-0 ${
                currentTab === 'sync' ? 'bg-white/20 font-bold' : 'text-[#D2E4D6]'
              }`}
            >
              Google Sheets
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
