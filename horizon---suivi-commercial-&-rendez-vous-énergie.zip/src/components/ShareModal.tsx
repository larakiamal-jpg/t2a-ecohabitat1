import React, { useState } from 'react';
import {
  Check,
  Copy,
  Download,
  ExternalLink,
  Globe,
  Lock,
  Shield,
  Smartphone,
  User,
  Users,
  X,
  Zap,
} from 'lucide-react';
import { Appointment, Agent } from '../types';
import { exportToCSV, isFictionalAgent } from '../utils/storage';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointments: Appointment[];
  agents: Agent[];
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  appointments,
  agents,
}) => {
  const [copiedCommercial, setCopiedCommercial] = useState(false);
  const [copiedAdmin, setCopiedAdmin] = useState(false);
  const [copiedGeneric, setCopiedGeneric] = useState(false);

  const validAgents = agents.filter((a) => !isFictionalAgent(a));
  const commercialAgents = validAgents.filter((a) => a.role === 'agent');
  const adminAgents = validAgents.filter((a) => a.role === 'administrateur');

  const [selectedCommercialId, setSelectedCommercialId] = useState<string>(
    commercialAgents[0]?.id || ''
  );

  if (!isOpen) return null;

  const baseUrl =
    typeof window !== 'undefined' && window.location.href
      ? window.location.href.split('?')[0].split('#')[0]
      : 'https://ais-pre-pcflmjwwcbzwwwjvxlnh3y-978746522618.europe-west2.run.app';

  const commercialGenericUrl = `${baseUrl}?role=commercial`;
  const commercialPersonalUrl = selectedCommercialId
    ? `${baseUrl}?user=${selectedCommercialId}`
    : commercialGenericUrl;
  const adminUrl = `${baseUrl}?user=${adminAgents[0]?.id || 'agent_sophie'}`;

  const copyToClipboard = (text: string, setCopiedState: (v: boolean) => void) => {
    navigator.clipboard.writeText(text);
    setCopiedState(true);
    setTimeout(() => setCopiedState(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-[#DBE4DC] shadow-2xl p-6 sm:p-8">
        <div className="flex items-start justify-between border-b border-[#DBE4DC] pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#14382F] text-white flex items-center justify-center shadow-sm">
              <Zap className="w-5 h-5 text-[#C9882B]" />
            </div>
            <div>
              <h2 className="font-editorial text-xl font-bold text-[#14382F]">
                Partager l’Application T2A ECOHABITAT
              </h2>
              <p className="text-xs text-[#5E7368] mt-0.5">
                Générez des liens sécurisés pour vos commerciaux terrain et vos administrateurs.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1. LIEN SÉCURISÉ POUR LES COMMERCIAUX (SANS CONFIGURATION) */}
        <div className="mb-6 bg-gradient-to-r from-emerald-50/70 to-teal-50/70 border-2 border-emerald-500/30 rounded-xl p-5">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-emerald-600 text-white flex items-center justify-center">
                <Lock className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-950">
                Lien Sécurisé pour les Commerciaux
              </span>
            </div>
            <span className="text-[11px] font-bold text-emerald-800 bg-white border border-emerald-300 px-2 py-0.5 rounded-full flex items-center gap-1 shadow-2xs">
              <Check className="w-3 h-3 text-emerald-600" />
              Configuration 100% Masquée & Protégée
            </span>
          </div>

          <p className="text-xs text-slate-700 mb-3 leading-relaxed">
            Les commerciaux qui ouvrent ce lien <strong>n'ont aucun accès</strong> à l'onglet Google Sheets ni aux paramètres techniques. Ils peuvent uniquement consulter leurs rendez-vous, l'agenda et enregistrer de nouveaux RDV qui se synchronisent automatiquement vers votre Sheet.
          </p>

          {/* Option A: Par commercial nominatif */}
          {commercialAgents.length > 0 && (
            <div className="mb-3 bg-white p-3 rounded-lg border border-emerald-200">
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Lien personnalisé pour un commercial en particulier :
              </label>
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={selectedCommercialId}
                  onChange={(e) => setSelectedCommercialId(e.target.value)}
                  className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none cursor-pointer"
                >
                  {commercialAgents.map((ag) => (
                    <option key={ag.id} value={ag.id}>
                      {ag.name} ({ag.phone || ag.email})
                    </option>
                  ))}
                </select>

                <button
                  onClick={() => copyToClipboard(commercialPersonalUrl, setCopiedCommercial)}
                  className="px-3.5 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
                >
                  {copiedCommercial ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#C9882B]" />
                      <span>Lien commercial copié !</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copier le lien de ce commercial</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Option B: Lien commercial générique */}
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={commercialGenericUrl}
              className="flex-1 bg-white border border-[#B8CABE] rounded-lg px-3 py-2 text-xs font-mono text-[#182B24] select-all focus:outline-none"
            />
            <button
              onClick={() => copyToClipboard(commercialGenericUrl, setCopiedGeneric)}
              className="px-4 py-2 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shadow-sm cursor-pointer"
            >
              {copiedGeneric ? (
                <>
                  <Check className="w-4 h-4 text-[#C9882B]" />
                  <span>Copié !</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copier lien générique</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* 2. LIEN ADMINISTRATEUR COMPLET */}
        <div className="mb-6 bg-slate-50 border border-slate-300 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#14382F] flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-[#C9882B]" />
              Lien Administrateur (Pour Sophie Vaillant & Direction)
            </span>
            <span className="text-[11px] font-semibold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              Accès Complet + Configuration
            </span>
          </div>
          <p className="text-xs text-[#5E7368] mb-2 leading-relaxed">
            Conservez ce lien pour vous-même ou vos administrateurs : il donne accès à la configuration Google Sheets, au diagnostic et à la gestion des utilisateurs.
          </p>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={adminUrl}
              className="flex-1 bg-white border border-[#B8CABE] rounded-lg px-3 py-2 text-xs font-mono text-[#182B24] select-all focus:outline-none"
            />
            <button
              onClick={() => copyToClipboard(adminUrl, setCopiedAdmin)}
              className="px-4 py-2 border border-[#14382F] text-[#14382F] hover:bg-slate-100 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
            >
              {copiedAdmin ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Lien Admin copié !</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copier lien Admin</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* 2. Three free ways to share / deploy */}
        <div className="space-y-4 mb-6">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#14382F]">
            3 options pour partager et utiliser l’application :
          </h3>

          {/* Option A: Direct Link & Mobile Home Screen */}
          <div className="p-4 rounded-xl border border-[#DBE4DC] hover:border-[#14382F]/40 transition-colors">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#14382F]">
                  1. Utiliser sur smartphone (iPhone & Android)
                </h4>
                <p className="text-xs text-[#5E7368] mt-1 leading-relaxed">
                  Ouvrez le lien ci-dessus sur le smartphone d'un commercial (dans Safari ou Chrome), puis cliquez sur <span className="font-semibold text-slate-800">« Partager » → « Ajouter à l’écran d’accueil »</span>. L'application se comporte exactement comme une application mobile native, sans passer par l'App Store et 100% gratuit.
                </p>
              </div>
            </div>
          </div>

          {/* Option B: Team Collaboration & Google Sheets */}
          <div className="p-4 rounded-xl border border-[#DBE4DC] hover:border-[#14382F]/40 transition-colors">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-900 flex items-center justify-center shrink-0 mt-0.5">
                <Users className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#14382F]">
                  2. Synchronisation collaborative avec Google Sheets
                </h4>
                <p className="text-xs text-[#5E7368] mt-1 leading-relaxed">
                  Dans l'onglet <span className="font-semibold text-slate-800">« Google Sheets / Script »</span>, connectez votre URL Apps Script gratuite. Tous les rendez-vous pris par vos commerciaux s’enregistrent en direct dans votre classeur Google Sheets partagé avec vos onglets (Prospects, Activités, Utilisateurs).
                </p>
              </div>
            </div>
          </div>

          {/* Option C: Custom domain / Vercel / GitHub */}
          <div className="p-4 rounded-xl border border-[#DBE4DC] hover:border-[#14382F]/40 transition-colors">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                <ExternalLink className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#14382F]">
                  3. Déploiement sur votre propre domaine (Gratuit avec Vercel ou Netlify)
                </h4>
                <p className="text-xs text-[#5E7368] mt-1 leading-relaxed">
                  Si vous souhaitez avoir votre propre nom de domaine personnalisé (ex: <code className="bg-slate-100 px-1 py-0.5 rounded text-[11px]">rdv.mon-entreprise-solaire.fr</code>), vous pouvez exporter ce projet sur GitHub et le lier à un compte gratuit Vercel ou Netlify en 2 minutes. L'hébergement y est également 100% gratuit.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 3. CSV Backup Button */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-[#DBE4DC]">
          <button
            onClick={() => exportToCSV(appointments, agents)}
            className="px-3.5 py-2 border border-[#9EB5A7] hover:bg-slate-50 text-[#14382F] rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#5E7368]" />
            Exporter les rendez-vous en CSV (Excel)
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-lg text-xs font-semibold transition-colors shadow-sm"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
