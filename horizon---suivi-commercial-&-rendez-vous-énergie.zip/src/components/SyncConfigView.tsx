import React, { useState, useEffect, useMemo } from 'react';
import { Agent, Appointment, DiagnosticResult, SyncConfig } from '../types';
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Code,
  Copy,
  Download,
  ExternalLink,
  FileSpreadsheet,
  Plus,
  RefreshCw,
  Save,
  Send,
  ShieldCheck,
  Sparkles,
  Terminal,
  Upload,
  User,
  Users,
  Zap,
} from 'lucide-react';
import {
  CRM_COLUMNS,
  exportToCSV,
  extractSpreadsheetId,
  getGoogleSheetUrl,
  isFictionalAgent,
  pushAllAppointmentsToGoogleSheet,
  pushAppointmentToGoogleSheet,
  saveSyncConfig,
  testAppsScriptConnection,
} from '../utils/storage';

interface SyncConfigViewProps {
  config: SyncConfig;
  onUpdateConfig: (newConfig: SyncConfig) => void;
  appointments: Appointment[];
  agents: Agent[];
  onImportAppointments: (imported: Appointment[]) => void;
  onSyncAll?: () => Promise<void>;
  isSyncing?: boolean;
  syncSuccessMessage?: string | null;
  syncErrorMessage?: string | null;
}

export const SyncConfigView: React.FC<SyncConfigViewProps> = ({
  config,
  onUpdateConfig,
  appointments,
  agents,
  onImportAppointments,
  onSyncAll,
  isSyncing = false,
  syncSuccessMessage = null,
  syncErrorMessage = null,
}) => {
  const [formData, setFormData] = useState<SyncConfig>(config);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testing, setTesting] = useState(false);
  const [localSyncing, setLocalSyncing] = useState(false);
  const [testingSingle, setTestingSingle] = useState(false);
  const [pulling, setPulling] = useState(false);
  const [localMessage, setLocalMessage] = useState<{ text: string; error?: boolean; isPermission?: boolean } | null>(null);
  const [diagnostics, setDiagnostics] = useState<DiagnosticResult[] | null>(null);
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedSheetUrl, setCopiedSheetUrl] = useState(false);
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [showColumnsModal, setShowColumnsModal] = useState(false);
  const [detectedVersion, setDetectedVersion] = useState<string | null>(null);
  const [detectedServiceName, setDetectedServiceName] = useState<string | null>(null);
  const [checkingVersion, setCheckingVersion] = useState(false);

  const validAgents: Agent[] = useMemo(() => agents.filter((a: Agent) => !isFictionalAgent(a)), [agents]);

  useEffect(() => {
    setFormData(config);
  }, [config]);

  // Live version detection from the active /exec endpoint
  useEffect(() => {
    let isCancelled = false;
    if (formData.exec_url && formData.exec_url.startsWith('https://')) {
      setCheckingVersion(true);
      fetch(formData.exec_url, { method: 'GET', credentials: 'omit' })
        .then((res) => res.json())
        .then((data) => {
          if (!isCancelled && data) {
            setDetectedVersion(data.version || 'inconnue');
            setDetectedServiceName(data.service || null);
          }
        })
        .catch(() => {
          if (!isCancelled) {
            setDetectedVersion(null);
            setDetectedServiceName(null);
          }
        })
        .finally(() => {
          if (!isCancelled) setCheckingVersion(false);
        });
    }
    return () => {
      isCancelled = true;
    };
  }, [formData.exec_url]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveSyncConfig(formData);
    onUpdateConfig(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleRunDiagnostic = async () => {
    setTesting(true);
    setDiagnostics(null);
    setLocalMessage(null);
    try {
      const results = await testAppsScriptConnection(formData.exec_url, formData.sheets_id);
      setDiagnostics(results);
    } finally {
      setTesting(false);
    }
  };

  // Test writing a single test appointment into the Google Sheet
  const handleTestWriteSingle = async () => {
    if (!formData.exec_url) {
      setLocalMessage({
        text: "Veuillez d'abord renseigner l'URL /exec d'Apps Script.",
        error: true,
      });
      return;
    }
    setTestingSingle(true);
    setLocalMessage(null);

    const testItem: Appointment = {
      id: `test-${Date.now().toString(36)}`,
      prospect_name: 'TEST CONNEXION T2A',
      phone: '06 00 00 00 00',
      email: 'test@t2a-ecohabitat.fr',
      postal_code: '44000',
      city: 'Nantes',
      address: '1 Rue de Test',
      project_type: 'panneaux photovoltaïques',
      date: new Date().toISOString().split('T')[0],
      time: '14:00',
      status: 'confirmé',
      agent_id: validAgents[0]?.id || 'agent_sophie',
      comment: 'Ligne de test générée pour valider l’écriture Google Sheets',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const res = await pushAppointmentToGoogleSheet(testItem, formData);
    setTestingSingle(false);

    if (res.success) {
      setLocalMessage({
        text: "Test réussi : Le rendez-vous de test a bien été écrit dans votre Google Sheet (onglet Prospects) !",
      });
    } else {
      setLocalMessage({
        text: `Échec du test : ${res.error}`,
        error: true,
        isPermission: res.isPermissionError,
      });
    }
  };

  const handleTriggerPush = async () => {
    if (onSyncAll) {
      await onSyncAll();
      return;
    }

    if (!formData.exec_url) {
      setLocalMessage({
        text: "Veuillez d'abord renseigner l'URL /exec d'Apps Script.",
        error: true,
      });
      return;
    }
    setLocalSyncing(true);
    setLocalMessage(null);

    const result = await pushAllAppointmentsToGoogleSheet(appointments, formData);
    setLocalSyncing(false);

    if (result.success) {
      setLocalMessage({
        text: `Succès : ${result.count} rendez-vous ont été envoyés et enregistrés dans le Google Sheet !`,
      });
    } else {
      setLocalMessage({
        text: `Erreur d'envoi : ${result.error}`,
        error: true,
        isPermission: result.isPermissionError,
      });
    }
  };

  const handlePullFromSheet = async () => {
    if (!formData.exec_url) {
      setLocalMessage({
        text: "Veuillez d'abord renseigner l'URL /exec d'Apps Script.",
        error: true,
      });
      return;
    }
    setPulling(true);
    setLocalMessage(null);
    try {
      const res = await fetch(formData.exec_url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        credentials: 'omit',
        body: JSON.stringify({
          action: 'listAuthorizedAppointments',
          sheets_id: formData.sheets_id,
        }),
      });
      const data = await res.json();
      if (data && data.ok && data.data && Array.isArray(data.data.appointments)) {
        const fetched = data.data.appointments;
        if (fetched.length === 0) {
          setLocalMessage({
            text: 'Connexion Google Sheets vérifiée : aucun rendez-vous trouvé dans l’onglet Prospects.',
          });
        } else {
          onImportAppointments(fetched);
          setLocalMessage({
            text: `Succès : ${fetched.length} rendez-vous ont été importés et synchronisés depuis votre Google Sheet !`,
          });
        }
      } else {
        setLocalMessage({
          text: `Réponse inattendue de Google Sheets : ${JSON.stringify(data).slice(0, 150)}`,
          error: true,
        });
      }
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Erreur inconnue';
      setLocalMessage({
        text: `Erreur d'importation depuis Google Sheets : ${errorMsg}`,
        error: true,
      });
    } finally {
      setPulling(false);
    }
  };

  // Google Apps Script Production Server Code for T2A ECOHABITAT (Version 3.1.0 - Anti-Décalage Dynamique)
  const appsScriptCode = `/**
 * T2A ECOHABITAT - Script de synchronisation Google Apps Script & Google Sheets
 * Version : 3.1.0 (Alignement dynamique strict anti-décalage)
 * Administrateur : Sophie Vaillant - T2A ECOHABITAT
 */

const SPREADSHEET_ID = "${formData.sheets_id || '1VWIJpeAqeePtF2NuSTxzVhnxZhzNwqZM-RxjK2UOl1U'}";

const CRM_HEADERS = [
  "stable_id", "owner_id", "type", "name", "first_name", "company", "job_title", 
  "phone", "email", "address", "postal_code", "city", "contact_type", "category", 
  "source", "status", "pipeline_stage", "housing_type", "notes", "estimated_value", 
  "rdv_date", "rdv_agent_setter", "rdv_agent_commercial", "rdv_status", "rdv_comment", 
  "next_action", "follow_up_date", "last_contact_date", "created_at", "updated_at", 
  "is_example", "metadata"
];

function initialiserNouveauClasseurT2AEcohabitat() {
  let ss = null;
  try {
    ss = SpreadsheetApp.getActiveSpreadsheet();
  } catch(e) {}
  if (!ss && SPREADSHEET_ID) {
    try {
      ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    } catch(e2) {}
  }
  if (!ss) throw new Error("Impossible d'accéder au classeur. Vérifiez l'ID de votre Google Sheet.");

  // Onglet CRM avec les 32 colonnes exactes
  let shCRM = ss.getSheetByName("CRM") || ss.getSheetByName("crm");
  if (!shCRM) {
    shCRM = ss.insertSheet("CRM", 0);
    shCRM.appendRow(CRM_HEADERS);
    shCRM.getRange(1, 1, 1, CRM_HEADERS.length).setBackground("#14382F").setFontColor("#FFFFFF").setFontWeight("bold");
    shCRM.setFrozenRows(1);
  } else if (shCRM.getLastRow() === 0) {
    shCRM.appendRow(CRM_HEADERS);
    shCRM.getRange(1, 1, 1, CRM_HEADERS.length).setBackground("#14382F").setFontColor("#FFFFFF").setFontWeight("bold");
    shCRM.setFrozenRows(1);
  }

  // Onglet Utilisateurs (Avec Sophie Vaillant)
  let shUsers = ss.getSheetByName("Utilisateurs");
  if (!shUsers) shUsers = ss.insertSheet("Utilisateurs");
  if (shUsers.getLastRow() === 0) {
    shUsers.appendRow(["ID_Agent", "Nom", "Email", "Role", "Telephone", "Couleur"]);
    shUsers.getRange(1, 1, 1, 6).setBackground("#14382F").setFontColor("#FFFFFF").setFontWeight("bold");
    shUsers.appendRow(["agent_sophie", "Sophie Vaillant", "sophie.vaillant@t2a-ecohabitat.fr", "administrateur", "06 20 30 40 50", "#14382F"]);
  }

  Logger.log("Classeur T2A ECOHABITAT (CRM 32 colonnes) initialisé avec succès !");
}

function initialiserNouveauClasseurHorizon() {
  initialiserNouveauClasseurT2AEcohabitat();
}

function doGet(e) {
  const response = {
    ok: true,
    status: "online",
    service: "T2A ECOHABITAT Synchronization API",
    admin: "Sophie Vaillant",
    timestamp: new Date().toISOString(),
    spreadsheetId: SPREADSHEET_ID,
    crm_columns_count: CRM_HEADERS.length,
    version: "3.1.0"
  };
  return ContentService.createTextOutput(JSON.stringify(response))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(10000);
  } catch (err) {
    return createJsonResponse({ ok: false, error: "Serveur Google temporairement saturé, réessayez dans quelques secondes." });
  }

  try {
    const raw = e && e.postData && e.postData.contents;
    if (!raw) return createJsonResponse({ ok: false, error: "Payload vide" });

    const body = JSON.parse(raw);
    const action = body.action || "ping";
    const payload = body.payload || {};
    const targetId = payload.sheets_id || body.sheets_id || SPREADSHEET_ID;

    let ss = null;
    try {
      ss = SpreadsheetApp.getActiveSpreadsheet();
    } catch(errActive) {}

    if (!ss) {
      try {
        ss = targetId ? SpreadsheetApp.openById(targetId) : null;
      } catch(errOpen) {}
    }

    if (!ss) {
      return createJsonResponse({
        ok: false,
        error: "PERMISSION_DENIED: Google refuse l'accès au classeur (" + (targetId || "ID non spécifié") + "). Ouvrez le Google Sheet, cliquez sur 'Partager', et passez 'Accès général' à 'Tous les utilisateurs disposant du lien' en 'Éditeur'."
      });
    }

    // 1. Ping / Test de connexion
    if (action === "ping" || action === "testSpreadsheetAccess") {
      let sheet = getTargetSheet(ss);
      return createJsonResponse({
        ok: true,
        message: "Accès au classeur '" + ss.getName() + "' validé avec succès !",
        spreadsheetName: ss.getName(),
        targetSheet: sheet ? sheet.getName() : "Aucun",
        hasCrmSheet: Boolean(ss.getSheetByName("CRM") || ss.getSheetByName("crm")),
        version: "3.1.0"
      });
    }

    // 2. Action d'importation vers l'app
    if (action === "listAuthorizedAppointments") {
      const sheet = getTargetSheet(ss);
      const rows = sheet.getDataRange().getValues();
      const appointments = [];
      if (rows.length > 1) {
        const headerRow = rows[0].map(function(h) { return String(h).trim().toLowerCase().replace(/[^a-z0-9_]/g, "_"); });
        const colIdx = function(name) { return headerRow.indexOf(name); };

        const idCol = colIdx("stable_id") >= 0 ? colIdx("stable_id") : colIdx("id");
        const nameCol = colIdx("name") >= 0 ? colIdx("name") : colIdx("nom");
        const fNameCol = colIdx("first_name") >= 0 ? colIdx("first_name") : colIdx("prenom");
        const pNameCol = colIdx("prospect_name") >= 0 ? colIdx("prospect_name") : colIdx("nom_prospect");
        const phoneCol = colIdx("phone") >= 0 ? colIdx("phone") : colIdx("telephone");
        const emailCol = colIdx("email") >= 0 ? colIdx("email") : colIdx("mail");
        const addrCol = colIdx("address") >= 0 ? colIdx("address") : colIdx("adresse");
        const pcCol = colIdx("postal_code") >= 0 ? colIdx("postal_code") : colIdx("code_postal");
        const cityCol = colIdx("city") >= 0 ? colIdx("city") : colIdx("ville");
        const catCol = colIdx("category") >= 0 ? colIdx("category") : colIdx("type_projet");
        const rdvDateCol = colIdx("rdv_date") >= 0 ? colIdx("rdv_date") : colIdx("date");
        const rdvTimeCol = colIdx("heure") >= 0 ? colIdx("heure") : colIdx("time");
        const rdvStatusCol = colIdx("rdv_status") >= 0 ? colIdx("rdv_status") : colIdx("statut");
        const rdvCommentCol = colIdx("rdv_comment") >= 0 ? colIdx("rdv_comment") : (colIdx("commentaire") >= 0 ? colIdx("commentaire") : colIdx("notes"));
        const ownerCol = colIdx("owner_id") >= 0 ? colIdx("owner_id") : colIdx("agent_id");

        for (let i = 1; i < rows.length; i++) {
          const r = rows[i];
          const rawId = idCol >= 0 ? r[idCol] : r[0];
          if (!rawId) continue;

          let fullName = "";
          if (pNameCol >= 0 && r[pNameCol]) {
            fullName = String(r[pNameCol]);
          } else {
            const nom = nameCol >= 0 ? String(r[nameCol] || "") : "";
            const prenom = fNameCol >= 0 ? String(r[fNameCol] || "") : "";
            fullName = (prenom + " " + nom).trim() || nom || "Client";
          }

          let dateStr = "";
          let timeStr = "14:00";
          const rawDate = rdvDateCol >= 0 ? r[rdvDateCol] : "";
          if (rawDate) {
            try {
              if (rawDate instanceof Date) {
                dateStr = Utilities.formatDate(rawDate, "Europe/Paris", "yyyy-MM-dd");
                timeStr = Utilities.formatDate(rawDate, "Europe/Paris", "HH:mm");
              } else {
                const parts = String(rawDate).split(" ");
                dateStr = parts[0];
                if (parts[1]) timeStr = parts[1];
              }
            } catch(e) {}
          }
          if (rdvTimeCol >= 0 && r[rdvTimeCol]) {
            timeStr = String(r[rdvTimeCol]);
          }

          appointments.push({
            id: String(rawId),
            prospect_name: fullName,
            phone: phoneCol >= 0 ? String(r[phoneCol] || "") : "",
            email: emailCol >= 0 ? String(r[emailCol] || "") : "",
            postal_code: pcCol >= 0 ? String(r[pcCol] || "") : "",
            city: cityCol >= 0 ? String(r[cityCol] || "") : "",
            address: addrCol >= 0 ? String(r[addrCol] || "") : "",
            project_type: catCol >= 0 ? String(r[catCol] || "panneaux photovoltaïques") : "panneaux photovoltaïques",
            date: dateStr || Utilities.formatDate(new Date(), "Europe/Paris", "yyyy-MM-dd"),
            time: timeStr || "14:00",
            status: rdvStatusCol >= 0 ? String(r[rdvStatusCol] || "à confirmer") : "à confirmer",
            agent_id: ownerCol >= 0 ? String(r[ownerCol] || "agent_sophie") : "agent_sophie",
            comment: rdvCommentCol >= 0 ? String(r[rdvCommentCol] || "") : ""
          });
        }
      }
      return createJsonResponse({ ok: true, data: { appointments: appointments, sheet: sheet.getName() } });
    }

    // 3. Action de création d'un rendez-vous unique (ALIGNEMENT STRICT PAR NOM DE COLONNE)
    if (action === "createAppointment") {
      let sheet = getTargetSheet(ss);
      const rowData = mapRecordToHeaders(sheet, payload);
      sheet.appendRow(rowData);
      return createJsonResponse({
        ok: true,
        data: {
          success: true,
          sheet: sheet.getName(),
          id: payload.stable_id || payload.id,
          columns_written: rowData.length
        }
      });
    }

    // 4. Action d'envoi groupé (ALIGNEMENT STRICT PAR NOM DE COLONNE)
    if (action === "batchCreateAppointments") {
      let sheet = getTargetSheet(ss);
      const list = (payload && payload.appointments) || body.appointments || [];
      let count = 0;
      for (let i = 0; i < list.length; i++) {
        const item = list[i];
        const rowData = mapRecordToHeaders(sheet, item);
        sheet.appendRow(rowData);
        count++;
      }
      return createJsonResponse({
        ok: true,
        data: {
          success: true,
          sheet: sheet.getName(),
          count: count
        }
      });
    }

    return createJsonResponse({ ok: true, message: "Action reçue" });
  } catch (err) {
    return createJsonResponse({ ok: false, error: err.message });
  } finally {
    lock.releaseLock();
  }
}

/**
 * Trouve l'onglet cible (CRM en priorité, ou l'onglet contenant les 32 colonnes)
 */
function getTargetSheet(ss) {
  var sheet = ss.getSheetByName("CRM") || ss.getSheetByName("crm");
  if (sheet) return sheet;

  // Chercher un onglet avec stable_id ou rdv_date
  var sheets = ss.getSheets();
  for (var i = 0; i < sheets.length; i++) {
    var sh = sheets[i];
    if (sh.getLastColumn() > 0) {
      var topRow = sh.getRange(1, 1, 1, Math.min(sh.getLastColumn(), 35)).getValues()[0].join(",").toLowerCase();
      if (topRow.indexOf("stable_id") !== -1 || topRow.indexOf("rdv_date") !== -1) {
        return sh;
      }
    }
  }

  var pSheet = ss.getSheetByName("Prospects");
  if (pSheet) return pSheet;

  return ss.getActiveSheet();
}

/**
 * Cœur de la solution anti-décalage :
 * Lit les en-têtes réels de la ligne 1 du Sheet et injecte chaque donnée
 * STRICTEMENT sous sa colonne correspondante. Aucun décalage possible !
 */
function mapRecordToHeaders(sheet, payload) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headerValues = sheet.getRange(1, 1, 1, lastCol).getValues()[0];

  // Si l'onglet est totalement vide, créer les 32 colonnes CRM
  if (sheet.getLastRow() === 0 || !headerValues[0]) {
    sheet.appendRow(CRM_HEADERS);
    sheet.getRange(1, 1, 1, CRM_HEADERS.length).setBackground("#14382F").setFontColor("#FFFFFF").setFontWeight("bold");
    sheet.setFrozenRows(1);
    headerValues = CRM_HEADERS;
    lastCol = CRM_HEADERS.length;
  }

  var rawName = String(payload.prospect_name || payload.name || "").trim();
  var parts = rawName ? rawName.split(/\s+/) : [];
  var firstName = payload.first_name || (parts.length > 1 ? parts[0] : "");
  var lastName = payload.name || (parts.length > 1 ? parts.slice(1).join(" ") : parts[0] || "");
  var rdvDateTime = (payload.rdv_date || (payload.date ? payload.date + " " + (payload.time || "") : "")).trim();
  var notes = [
    payload.comment || payload.notes || "",
    payload.current_heating ? "Chauffage: " + payload.current_heating : "",
    payload.roof_orientation ? "Toiture: " + payload.roof_orientation : "",
    payload.estimated_power ? "Puissance: " + payload.estimated_power : ""
  ].filter(Boolean).join(" | ");

  // Dictionnaire universel avec tous les synonymes de colonnes
  var map = {
    stable_id: payload.stable_id || payload.id || Utilities.getUuid(),
    id: payload.stable_id || payload.id || Utilities.getUuid(),
    owner_id: payload.owner_id || payload.agent_id || "agent_sophie",
    agent_id: payload.owner_id || payload.agent_id || "agent_sophie",
    type: payload.type || "particulier",
    name: lastName,
    nom: lastName,
    first_name: firstName,
    prenom: firstName,
    prospect_name: rawName,
    nom_prospect: rawName,
    company: payload.company || "",
    societe: payload.company || "",
    job_title: payload.job_title || "",
    phone: payload.phone || payload.telephone || "",
    telephone: payload.phone || payload.telephone || "",
    email: payload.email || payload.mail || "",
    mail: payload.email || payload.mail || "",
    address: payload.address || payload.adresse || "",
    adresse: payload.address || payload.adresse || "",
    postal_code: payload.postal_code || payload.code_postal || "",
    code_postal: payload.postal_code || payload.code_postal || "",
    city: payload.city || payload.ville || "",
    ville: payload.city || payload.ville || "",
    contact_type: payload.contact_type || "Prospect",
    category: payload.category || payload.project_type || "panneaux photovoltaïques",
    type_projet: payload.category || payload.project_type || "panneaux photovoltaïques",
    source: payload.source || "T2A ECOHABITAT",
    status: payload.status || payload.rdv_status || "à confirmer",
    statut: payload.status || payload.rdv_status || "à confirmer",
    pipeline_stage: payload.pipeline_stage || (payload.status === "confirmé" ? "Rendez-vous planifié" : "Rendez-vous pris"),
    housing_type: payload.housing_type || "Maison individuelle",
    notes: notes,
    commentaire: payload.comment || payload.notes || "",
    comment: payload.comment || payload.notes || "",
    estimated_value: payload.estimated_value || payload.estimated_power || "",
    puissance: payload.estimated_power || "",
    rdv_date: rdvDateTime || payload.date || "",
    date: payload.date || (rdvDateTime ? rdvDateTime.split(" ")[0] : ""),
    time: payload.time || (rdvDateTime ? rdvDateTime.split(" ")[1] : "14:00"),
    heure: payload.time || (rdvDateTime ? rdvDateTime.split(" ")[1] : "14:00"),
    rdv_agent_setter: payload.rdv_agent_setter || payload.agent_name || "Sophie Vaillant",
    rdv_agent_commercial: payload.rdv_agent_commercial || payload.agent_name || "Sophie Vaillant",
    rdv_status: payload.rdv_status || payload.status || "à confirmer",
    rdv_comment: payload.rdv_comment || payload.comment || "",
    next_action: payload.next_action || "Visite technique / Devis",
    follow_up_date: payload.follow_up_date || payload.date || "",
    last_contact_date: payload.last_contact_date || Utilities.formatDate(new Date(), "Europe/Paris", "yyyy-MM-dd"),
    created_at: payload.created_at || new Date().toISOString(),
    date_creation: payload.created_at || new Date().toISOString(),
    updated_at: payload.updated_at || new Date().toISOString(),
    is_example: false,
    metadata: typeof payload.metadata === "string" ? payload.metadata : JSON.stringify(payload.metadata || {})
  };

  // Construction ligne par ligne selon l'ordre strict des en-têtes réels du Sheet
  var row = [];
  for (var i = 0; i < headerValues.length; i++) {
    var rawH = String(headerValues[i] || "").trim().toLowerCase().replace(/[^a-z0-9_]/g, "_");
    if (map.hasOwnProperty(rawH)) {
      row.push(map[rawH]);
    } else {
      row.push("");
    }
  }
  return row;
}

function createJsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}`;

  const copyScriptToClipboard = () => {
    navigator.clipboard.writeText(appsScriptCode);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2500);
  };

  const activeSyncing = isSyncing || localSyncing;
  const activeMessage = syncSuccessMessage ? { text: syncSuccessMessage } : syncErrorMessage ? { text: syncErrorMessage, error: true } : localMessage;

  return (
    <div className="space-y-6 animate-fadeIn max-w-5xl mx-auto">
      {/* MEGA BANNER: POUSSER LES RDV VERS LE SHEET */}
      <div className="bg-[#14382F] text-white border border-[#0D2620] rounded-2xl p-6 sm:p-7 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-6">
          <div className="space-y-1 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#C9882B]">
                Action Principale
              </span>
              <span className="text-[11px] bg-emerald-900/80 text-emerald-200 border border-emerald-500/40 px-2 py-0.5 rounded-full font-semibold">
                ● Script connecté & actif
              </span>
            </div>
            <h2 className="font-editorial text-2xl font-bold text-white">
              Synchroniser les données avec votre Google Sheet
            </h2>
            <p className="text-xs text-[#D2E4D6] leading-relaxed">
              Envoie instantanément tous les rendez-vous ({appointments.length}), prospects et l'équipe vers votre classeur Google Sheets connecté.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {formData.sheets_id && (
              <a
                href={getGoogleSheetUrl(formData.sheets_id)}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-3.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl flex items-center gap-2 border border-white/20 transition-all cursor-pointer whitespace-nowrap"
              >
                <ExternalLink className="w-4 h-4 text-[#C9882B]" />
                <span>Ouvrir mon Google Sheet</span>
              </a>
            )}
            <button
              onClick={handleTriggerPush}
              disabled={activeSyncing}
              className="px-6 py-3.5 bg-[#C9882B] hover:bg-[#b57723] text-[#14382F] font-bold text-sm rounded-xl flex items-center gap-2.5 shadow-md transition-all transform hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 cursor-pointer whitespace-nowrap"
            >
              <Send className={`w-5 h-5 ${activeSyncing ? 'animate-bounce' : ''}`} />
              <span>
                {activeSyncing ? 'Synchronisation en cours...' : 'POUSSER LES RDV VERS LE SHEET'}
              </span>
            </button>
          </div>
        </div>

        {activeMessage && (
          <div
            className={`mt-4 p-3.5 rounded-xl border text-xs flex items-center gap-2.5 font-medium ${
              activeMessage.error
                ? 'bg-amber-900/40 border-amber-400 text-amber-200'
                : 'bg-emerald-900/50 border-emerald-400 text-emerald-100'
            }`}
          >
            {activeMessage.error ? (
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            )}
            <span>{activeMessage.text}</span>
          </div>
        )}
      </div>

      {/* ADRESSE OFFICIELLE DU GOOGLE SHEET & STRUCTURE CRM */}
      <div className="bg-white border-2 border-[#14382F]/20 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-[#DBE4DC]">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#C9882B] bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
                Lien Direct & Fichier CRM
              </span>
              <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                <Check className="w-3 h-3 text-emerald-600" />
                32 Colonnes Connectées
              </span>
            </div>
            <h3 className="font-editorial text-xl font-bold text-[#14382F]">
              Adresse de votre Google Sheet
            </h3>
            <p className="text-xs text-[#5E7368]">
              Voici l'adresse exacte et directe de votre classeur Google Sheets connecté à T2A ECOHABITAT :
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                const sheetUrl = getGoogleSheetUrl(formData.sheets_id);
                navigator.clipboard.writeText(sheetUrl);
                setCopiedSheetUrl(true);
                setTimeout(() => setCopiedSheetUrl(false), 2500);
              }}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-[#14382F] rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5 text-[#C9882B]" />
              <span>{copiedSheetUrl ? 'Adresse copiée !' : "Copier l'adresse"}</span>
            </button>

            <a
              href={getGoogleSheetUrl(formData.sheets_id)}
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#C9882B]" />
              <span>Ouvrir mon Google Sheet</span>
            </a>
          </div>
        </div>

        {/* URL Box */}
        <div className="mt-4 p-3.5 bg-[#FAFBF8] border border-[#B8CABE] rounded-xl flex flex-wrap items-center justify-between gap-3 font-mono text-xs text-[#14382F]">
          <div className="flex items-center gap-2 min-w-0 flex-1 break-all">
            <FileSpreadsheet className="w-4 h-4 text-[#C9882B] shrink-0" />
            <a
              href={getGoogleSheetUrl(formData.sheets_id)}
              target="_blank"
              rel="noreferrer"
              className="text-[#14382F] hover:text-[#C9882B] underline font-bold"
            >
              {getGoogleSheetUrl(formData.sheets_id)}
            </a>
          </div>
          <div className="text-[11px] text-[#5E7368] font-sans shrink-0">
            ID : <span className="font-mono font-bold text-slate-800">{formData.sheets_id}</span>
          </div>
        </div>

        {/* Structure CRM 32 colonnes reconnue */}
        <div className="mt-4 pt-4 border-t border-[#DBE4DC]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#C9882B]" />
              <span className="text-xs font-bold text-[#14382F]">
                Structure CRM détectée (32 colonnes pour l'onglet "CRM")
              </span>
            </div>
            <button
              onClick={() => setShowColumnsModal(!showColumnsModal)}
              className="text-[11px] text-[#C9882B] hover:text-[#b57723] font-bold underline cursor-pointer"
            >
              {showColumnsModal ? 'Masquer les 32 colonnes' : 'Afficher les 32 colonnes'}
            </button>
          </div>

          {showColumnsModal && (
            <div className="mt-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <p className="text-[11px] text-[#5E7368] mb-2">
                Chaque rendez-vous synchronisé remplit automatiquement ces 32 colonnes dans votre Google Sheet :
              </p>
              <div className="flex flex-wrap gap-1.5">
                {CRM_COLUMNS.map((col, idx) => (
                  <span
                    key={col}
                    className="text-[10px] font-mono bg-white border border-slate-300 px-2 py-0.5 rounded text-slate-700 shadow-2xs"
                  >
                    <span className="text-[#C9882B] font-bold mr-1">{idx + 1}.</span>
                    {col}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* BANNIÈRE DE CORRECTION DU DÉCALAGE DES COLONNES */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-400 rounded-2xl p-6 shadow-md text-[#14382F] animate-fadeIn">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-sm mt-0.5">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div className="space-y-3 flex-1">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider bg-amber-200/80 text-amber-900 border border-amber-300 px-2 py-0.5 rounded">
                  Solution Anti-Décalage
                </span>
                <span className="text-[11px] font-semibold text-slate-700 bg-white border border-slate-200 px-2 py-0.5 rounded">
                  Script v3.1.0 disponible
                </span>
              </div>
              <h3 className="font-editorial text-xl font-bold text-amber-950">
                Pourquoi y a-t-il un décalage des colonnes dans votre Google Sheet ?
              </h3>
              <p className="text-xs text-amber-950/90 mt-1 leading-relaxed">
                Votre script Google Apps Script exécute encore l'ancienne version <strong>2.1.0</strong> (qui écrit 14 colonnes génériques par défaut), alors que votre feuille Google Sheet comporte la structure <strong>CRM à 32 colonnes</strong> (avec <code className="bg-amber-200/60 px-1 py-0.2 rounded font-mono text-[11px]">owner_id</code>, <code className="bg-amber-200/60 px-1 py-0.2 rounded font-mono text-[11px]">type</code>, <code className="bg-amber-200/60 px-1 py-0.2 rounded font-mono text-[11px]">name</code>, <code className="bg-amber-200/60 px-1 py-0.2 rounded font-mono text-[11px]">first_name</code>...).
              </p>
            </div>

            <div className="bg-white/95 rounded-xl border border-amber-300 p-4 space-y-3 shadow-xs">
              <div className="flex items-center gap-2 font-bold text-xs text-amber-950">
                <Sparkles className="w-4 h-4 text-[#C9882B]" />
                <span>Correction en 3 clics simples (30 secondes chrono) :</span>
              </div>
              <ol className="list-decimal pl-5 space-y-2 text-xs text-slate-800">
                <li className="leading-relaxed">
                  <strong>Copiez le nouveau script correcteur</strong> en cliquant sur le bouton ci-dessous :
                  <div className="mt-1.5">
                    <button
                      type="button"
                      onClick={copyScriptToClipboard}
                      className="px-4 py-2 bg-[#C9882B] hover:bg-[#b57723] text-[#14382F] font-bold rounded-lg text-xs flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{copiedScript ? '✓ Script v3.1.0 copié dans le presse-papiers !' : '1. Copier le nouveau Script Anti-Décalage (v3.1.0)'}</span>
                    </button>
                  </div>
                </li>
                <li className="leading-relaxed">
                  Dans votre Google Sheet, allez dans le menu supérieur : <strong className="text-[#14382F]">Extensions ➔ Apps Script</strong>.
                  Sélectionnez tout le texte existant (<kbd className="bg-slate-100 px-1 py-0.5 border border-slate-300 rounded font-mono text-[10px]">Ctrl+A</kbd> ou <kbd className="bg-slate-100 px-1 py-0.5 border border-slate-300 rounded font-mono text-[10px]">Cmd+A</kbd>) et collez le nouveau script. Cliquez sur l'icône de disquette 💾 (Enregistrer).
                </li>
                <li className="leading-relaxed">
                  <strong>Étape cruciale :</strong> En haut à droite d'Apps Script, cliquez sur le bouton bleu <strong className="text-[#14382F]">Déployer</strong> ➔ <strong className="text-[#14382F]">Gérer les déploiements</strong> ➔ cliquez sur le petit crayon ✏️ (Modifier) ➔ dans le champ Version, choisissez <strong className="text-emerald-800 bg-emerald-100 px-1 rounded">« Nouvelle version »</strong> ➔ cliquez sur <strong className="text-[#14382F]">Déployer</strong>.
                </li>
              </ol>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              <a
                href={getGoogleSheetUrl(formData.sheets_id)}
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-2 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <ExternalLink className="w-3.5 h-3.5 text-[#C9882B]" />
                <span>Ouvrir mon Google Sheet (pour aller dans Extensions → Apps Script)</span>
              </a>

              <button
                type="button"
                onClick={() => setShowCodeModal(true)}
                className="px-3.5 py-2 border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Code className="w-3.5 h-3.5 text-[#C9882B]" />
                <span>Voir le code du script v3.1.0</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Guide Étape par Étape pour créer le Sheet */}
      <div className="bg-[#FAFBF8] border border-[#C9882B]/40 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-8 h-8 rounded-lg bg-[#C9882B] text-[#14382F] flex items-center justify-center font-bold">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-editorial text-lg font-bold text-[#14382F]">
              Créer votre nouveau Google Sheet Dédié pour T2A ECOHABITAT
            </h2>
            <p className="text-xs text-[#5E7368]">
              Si vous souhaitez créer ou connecter un classeur personnalisé pour T2A ECOHABITAT :
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4 mt-4">
          {/* Étape 1 */}
          <div className="bg-white p-4 rounded-xl border border-[#DBE4DC]">
            <div className="text-xs font-bold text-[#C9882B] uppercase tracking-wider mb-1">
              Étape 1
            </div>
            <h3 className="font-bold text-sm text-[#14382F] mb-1">
              Créer le classeur vide
            </h3>
            <p className="text-xs text-[#5E7368] mb-3">
              Ouvrez Google Sheets pour générer un nouveau classeur vierge dans votre Google Drive :
            </p>
            <a
              href="https://docs.google.com/spreadsheets/d/create"
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Ouvrir Google Sheets</span>
            </a>
          </div>

          {/* Étape 2 */}
          <div className="bg-white p-4 rounded-xl border border-[#DBE4DC]">
            <div className="text-xs font-bold text-[#C9882B] uppercase tracking-wider mb-1">
              Étape 2
            </div>
            <h3 className="font-bold text-sm text-[#14382F] mb-1">
              Initialiser les 4 onglets
            </h3>
            <p className="text-xs text-[#5E7368] mb-3">
              Dans Google Sheets, cliquez sur <strong className="text-slate-800">Extensions → Apps Script</strong>, collez le script et lancez la fonction <code className="bg-slate-100 px-1 rounded text-[11px] font-semibold">initialiserNouveauClasseurT2AEcohabitat()</code> :
            </p>
            <button
              onClick={copyScriptToClipboard}
              className="w-full px-3 py-1.5 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copiedScript ? 'Copié !' : 'Copier le script complet'}</span>
            </button>
          </div>

          {/* Étape 3 */}
          <div className="bg-white p-4 rounded-xl border border-[#DBE4DC]">
            <div className="text-xs font-bold text-[#C9882B] uppercase tracking-wider mb-1">
              Étape 3
            </div>
            <h3 className="font-bold text-sm text-[#14382F] mb-1">
              Coller l’URL ou l’ID du Sheet
            </h3>
            <p className="text-xs text-[#5E7368] mb-2 leading-relaxed">
              Copiez directement l'URL complète ou l'identifiant de votre Sheet :
            </p>
            <div className="bg-slate-100 p-2 rounded text-[10px] font-mono text-slate-700 break-all mb-2">
              docs.google.com/spreadsheets/d/<span className="bg-[#C9882B]/30 font-bold text-[#14382F] px-1 rounded">VOTRE_ID</span>/edit
            </div>
            <p className="text-[11px] text-[#5E7368]">
              Collez-le ci-dessous, il sera nettoyé et relié automatiquement.
            </p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column (2 spans): Configuration & Real Diagnostics */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 shadow-sm">
            <h2 className="font-editorial text-xl font-bold text-[#14382F] mb-4 flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-[#C9882B]" />
              Paramètres du Web App & Identifiant du Classeur
            </h2>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  URL /exec du déploiement Google Apps Script Web App
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://script.google.com/macros/s/.../exec"
                  value={formData.exec_url}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, exec_url: e.target.value.trim() }))
                  }
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs font-mono text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />

                {/* Live Version Detector Banner */}
                {checkingVersion && (
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    Vérification de la version du script en cours...
                  </span>
                )}

                {!checkingVersion && detectedVersion && (
                  <div
                    className={`mt-2 p-2.5 rounded-lg border text-xs flex flex-wrap items-center justify-between gap-2 ${
                      detectedVersion === '3.1.0'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                        : 'bg-amber-50 border-amber-300 text-amber-900'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      {detectedVersion === '3.1.0' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                      )}
                      <span>
                        {detectedVersion === '3.1.0' ? (
                          <strong>Script à jour (v3.1.0) : Alignement 32 colonnes actif !</strong>
                        ) : (
                          <span>
                            <strong>Version active sur cette URL : v{detectedVersion} ({detectedServiceName || 'Ancien script'})</strong>
                            <br />
                            <span className="text-[11px] text-amber-800">
                              Cette URL renvoie encore l'ancien code. Si vous avez cliqué sur "Nouveau déploiement", collez la <strong>nouvelle URL</strong> ici et cliquez sur "Enregistrer paramètres".
                            </span>
                          </span>
                        )}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-[#182B24]">
                    Identifiant ou Lien complet de votre Google Sheet *
                  </label>
                  {formData.sheets_id && (
                    <a
                      href={getGoogleSheetUrl(formData.sheets_id)}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] font-bold text-[#14382F] hover:underline"
                    >
                      <ExternalLink className="w-3 h-3 text-[#C9882B]" />
                      <span>Ouvrir dans Google Sheets</span>
                    </a>
                  )}
                </div>
                <input
                  type="text"
                  required
                  placeholder="Collez ici l'URL complète ou l'identifiant (ex: 1VWIJpeAqeePtF2NuSTxzVhnxZhzNwqZM-RxjK2UOl1U)"
                  value={formData.sheets_id}
                  onChange={(e) => {
                    const extracted = extractSpreadsheetId(e.target.value);
                    setFormData((prev) => ({ ...prev, sheets_id: extracted }));
                  }}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs font-mono text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
                {formData.sheets_id && (
                  <div className="mt-1.5 flex flex-wrap items-center gap-2">
                    <span className="text-[11px] font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded font-semibold">
                      ID Détecté : {formData.sheets_id}
                    </span>
                    <span className="text-[11px] text-[#5E7368]">
                      Lien direct généré automatiquement.
                    </span>
                  </div>
                )}
                <span className="text-[11px] text-[#5E7368] mt-1 block">
                  Onglets cibles créés par le script : <strong className="text-slate-800">Prospects</strong>, <strong className="text-slate-800">Utilisateurs</strong>, <strong className="text-slate-800">Activites</strong>, <strong className="text-slate-800">Journal_Sync</strong>.
                </span>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#DBE4DC]">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={handleRunDiagnostic}
                    disabled={testing || !formData.exec_url}
                    className="px-3.5 py-2 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
                    <span>{testing ? 'Diagnostic...' : 'Diagnostiquer la connexion'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleTestWriteSingle}
                    disabled={testingSingle || !formData.exec_url}
                    className="px-3.5 py-2 border border-[#C9882B] hover:bg-amber-50 text-[#14382F] rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
                    title="Envoie un rendez-vous d'essai pour vérifier si Google autorise l'écriture"
                  >
                    <Send className={`w-3.5 h-3.5 text-[#C9882B] ${testingSingle ? 'animate-spin' : ''}`} />
                    <span>{testingSingle ? 'Test écriture...' : 'Tester écriture (1 RDV test)'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleTriggerPush}
                    disabled={activeSyncing}
                    className="px-3.5 py-2 bg-[#C9882B] hover:bg-[#b57723] text-[#14382F] rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs disabled:opacity-50 cursor-pointer"
                  >
                    <Send className={`w-3.5 h-3.5 ${activeSyncing ? 'animate-bounce' : ''}`} />
                    <span>Pousser les RDV vers le Sheet</span>
                  </button>

                  <button
                    type="button"
                    onClick={handlePullFromSheet}
                    disabled={pulling || !formData.exec_url}
                    className="px-3.5 py-2 border border-[#14382F] hover:bg-slate-50 text-[#14382F] rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    <Download className={`w-3.5 h-3.5 ${pulling ? 'animate-spin' : ''}`} />
                    <span>{pulling ? 'Import...' : 'Importer depuis le Sheet'}</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  {savedSuccess && (
                    <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Enregistré !
                    </span>
                  )}
                  <button
                    type="submit"
                    className="px-4 py-2 border border-[#14382F] text-[#14382F] hover:bg-slate-50 rounded-lg text-xs font-bold transition-colors shadow-xs"
                  >
                    <Save className="w-3.5 h-3.5 inline mr-1" />
                    <span>Enregistrer paramètres</span>
                  </button>
                </div>
              </div>
            </form>
          </div>

          {/* Special Permission Solution Banner if permission error detected */}
          {(localMessage?.isPermission || diagnostics?.some((d) => !d.success && d.details.includes('PERMISSION REFUSÉE'))) && (
            <div className="bg-amber-50 border-2 border-amber-400 rounded-2xl p-6 shadow-md animate-fadeIn text-[#14382F]">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-200 text-amber-900 flex items-center justify-center shrink-0 mt-0.5">
                  <AlertCircle className="w-5 h-5 text-amber-800" />
                </div>
                <div className="space-y-3 flex-1">
                  <div>
                    <h3 className="font-editorial text-lg font-bold text-amber-950">
                      Pourquoi le rendez-vous n'est pas arrivé dans votre Sheet ? (Permission Google)
                    </h3>
                    <p className="text-xs text-amber-900 mt-1 leading-relaxed">
                      Google refuse l'accès au classeur <code className="bg-amber-200/60 px-1 rounded font-bold font-mono text-[11px]">{formData.sheets_id}</code> car les permissions de partage ne sont pas encore ouvertes en mode <strong>Éditeur</strong> pour le script.
                    </p>
                  </div>

                  <div className="bg-white/90 p-4 rounded-xl border border-amber-300 text-xs space-y-2">
                    <div className="font-bold text-amber-950 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#C9882B]" />
                      <span>Résolution immédiate en 3 étapes (10 secondes) :</span>
                    </div>
                    <ol className="list-decimal pl-5 space-y-1.5 text-amber-950 text-xs">
                      <li>
                        Ouvrez votre Google Sheet en cliquant ici :{' '}
                        <a
                          href={getGoogleSheetUrl(formData.sheets_id)}
                          target="_blank"
                          rel="noreferrer"
                          className="font-bold underline text-[#14382F] hover:text-[#C9882B]"
                        >
                          Accéder à mon Google Sheet ↗
                        </a>
                      </li>
                      <li>
                        En haut à droite de Google Sheets, cliquez sur le gros bouton bleu <strong>« Partager »</strong>.
                      </li>
                      <li>
                        Sous <strong>« Accès général »</strong>, changez <em>« Limité »</em> par <strong>« Tous les utilisateurs disposant du lien »</strong>, et réglez le rôle sur <strong>« Éditeur »</strong>.
                      </li>
                      <li>
                        Cliquez sur <strong>« Terminé »</strong>.
                      </li>
                    </ol>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <a
                      href={getGoogleSheetUrl(formData.sheets_id)}
                      target="_blank"
                      rel="noreferrer"
                      className="px-4 py-2 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-[#C9882B]" />
                      <span>1. Ouvrir le Sheet pour changer le partage</span>
                    </a>
                    <button
                      type="button"
                      onClick={handleTestWriteSingle}
                      disabled={testingSingle}
                      className="px-4 py-2 bg-[#C9882B] hover:bg-[#b57723] text-[#14382F] rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${testingSingle ? 'animate-spin' : ''}`} />
                      <span>2. Re-tester l'écriture immédiate</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Diagnostic Panel */}
          {diagnostics && (
            <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 shadow-sm space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <h3 className="font-editorial text-lg font-bold text-[#14382F] flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-[#C9882B]" />
                  Diagnostic de l’URL Apps Script
                </h3>
                <span className="text-xs text-[#5E7368]">
                  {diagnostics.every((d) => d.success) ? (
                    <span className="text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      Connexion Validée
                    </span>
                  ) : (
                    <span className="text-amber-800 font-semibold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      Vérification requise
                    </span>
                  )}
                </span>
              </div>

              <div className="space-y-3">
                {diagnostics.map((res, idx) => (
                  <div
                    key={idx}
                    className={`p-3.5 rounded-xl border text-xs ${
                      res.success
                        ? 'border-emerald-200 bg-emerald-50/50 text-emerald-950'
                        : 'border-amber-200 bg-amber-50/50 text-amber-950'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1 font-bold">
                      <div className="flex items-center gap-1.5">
                        {res.success ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-amber-600" />
                        )}
                        <span>{res.step}</span>
                      </div>
                      <span className="font-mono text-[10px] text-slate-500">{res.timestamp}</span>
                    </div>
                    <p className="mt-1 leading-relaxed text-[11px]">{res.details}</p>
                    {res.dataSnippet && (
                      <div className="mt-2 bg-black/5 p-2 rounded text-[10px] font-mono break-all">
                        Données reçues : {res.dataSnippet}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Code Generator & Users export */}
        <div className="space-y-6">
          {/* Synchronized Users Card */}
          <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-[#C9882B]" />
                <h3 className="font-editorial text-base font-bold text-[#14382F]">
                  Onglet « Utilisateurs » ({validAgents.length})
                </h3>
              </div>
            </div>
            <p className="text-xs text-[#5E7368] mb-3 leading-relaxed">
              Liste des utilisateurs avec <strong className="text-slate-800">Sophie Vaillant</strong> en Administratrice :
            </p>

            <div className="space-y-2 mb-4 max-h-48 overflow-y-auto divide-y divide-[#DBE4DC]/60 pr-1 text-xs">
              {validAgents.map((a: Agent) => (
                <div key={a.id} className="pt-2 first:pt-0 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-[#14382F] block">{a.name}</span>
                    <span className="text-[10px] text-[#5E7368]">{a.phone}</span>
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                    a.role === 'administrateur' ? 'bg-amber-100 text-amber-900' : 'bg-emerald-100 text-emerald-900'
                  }`}>
                    {a.role === 'administrateur' ? 'Admin' : 'Commercial'}
                  </span>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                const headers = ['ID_Agent', 'Nom', 'Email', 'Role', 'Telephone', 'Couleur'];
                const rows = validAgents.map((a: Agent) => [
                  a.id,
                  `"${a.name.replace(/"/g, '""')}"`,
                  `"${a.email}"`,
                  a.role,
                  `"${a.phone}"`,
                  a.color,
                ]);
                const content = '\uFEFF' + [headers.join(';'), ...rows.map((r: string[]) => r.join(';'))].join('\n');
                const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `t2a-ecohabitat-utilisateurs-sophie-vaillant.csv`;
                link.click();
                URL.revokeObjectURL(url);
              }}
              className="w-full px-3 py-2 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-[#5E7368]" />
              <span>Télécharger l’onglet Utilisateurs (CSV)</span>
            </button>
          </div>

          {/* Apps Script Template Generator */}
          <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 shadow-sm">
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center mb-3">
              <Code className="w-5 h-5 text-amber-800" />
            </div>
            <h3 className="font-editorial text-lg font-bold text-[#14382F] mb-1">
              Script d'Initialisation Automatique
            </h3>
            <p className="text-xs text-[#5E7368] mb-4 leading-relaxed">
              Ce script crée automatiquement les 4 onglets, les en-têtes verts forêt et configure Sophie Vaillant dans votre classeur.
            </p>

            <button
              onClick={copyScriptToClipboard}
              className="w-full px-4 py-2.5 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-sm mb-2"
            >
              {copiedScript ? (
                <>
                  <Check className="w-4 h-4 text-[#C9882B]" />
                  <span>Script complet copié !</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copier le script Google Apps Script</span>
                </>
              )}
            </button>

            <button
              onClick={() => setShowCodeModal(true)}
              className="w-full px-4 py-2 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Voir le code source</span>
            </button>
          </div>
        </div>
      </div>

      {/* Code Modal */}
      {showCodeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[85vh] flex flex-col border border-[#DBE4DC] shadow-2xl p-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#DBE4DC] mb-4">
              <h3 className="font-editorial text-lg font-bold text-[#14382F]">
                Code source Apps Script complet (Code.gs)
              </h3>
              <button
                onClick={() => setShowCodeModal(false)}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800"
              >
                Fermer
              </button>
            </div>
            <div className="flex-1 overflow-y-auto bg-slate-900 text-slate-200 p-4 rounded-xl font-mono text-[11px] leading-relaxed">
              <pre>{appsScriptCode}</pre>
            </div>
            <div className="flex justify-end gap-2 pt-4 border-t border-[#DBE4DC] mt-4">
              <button
                onClick={copyScriptToClipboard}
                className="px-4 py-2 bg-[#14382F] text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copier le code</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
