import React, { useState, useMemo } from 'react';
import { Agent, Appointment, UserRole } from '../types';
import {
  Check,
  Edit2,
  Mail,
  Phone,
  PlusCircle,
  Shield,
  Trash2,
  User,
  UserCheck,
  UserPlus,
  Users,
  X,
  Zap,
} from 'lucide-react';
import { isFictionalAgent } from '../utils/storage';

interface TeamManagementViewProps {
  agents: Agent[];
  appointments: Appointment[];
  activeUser: Agent;
  onAddAgent: (agent: Agent) => void;
  onUpdateAgent: (agent: Agent) => void;
  onDeleteAgent: (id: string) => void;
  onSwitchUser: (agent: Agent) => void;
}

export const TeamManagementView: React.FC<TeamManagementViewProps> = ({
  agents,
  appointments,
  activeUser,
  onAddAgent,
  onUpdateAgent,
  onDeleteAgent,
  onSwitchUser,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [agentToDelete, setAgentToDelete] = useState<Agent | null>(null);
  const [roleFilter, setRoleFilter] = useState<'all' | 'administrateur' | 'agent'>('all');

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    role: 'agent' as UserRole,
    color: '#0D6E58',
  });

  const COLOR_PALETTE = [
    '#14382F', // Forest green
    '#C9882B', // Amber
    '#0D6E58', // Teal
    '#3B6A8A', // Slate blue
    '#7D4F7E', // Plum
    '#B44A3F', // Terracotta
    '#2E5B88', // Deep blue
    '#4A7C59', // Olive
  ];

  const handleOpenAdd = () => {
    setEditingAgent(null);
    setFormData({
      name: '',
      email: '',
      phone: '',
      role: 'agent',
      color: COLOR_PALETTE[Math.floor(Math.random() * COLOR_PALETTE.length)],
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (agent: Agent) => {
    setEditingAgent(agent);
    setFormData({
      name: agent.name,
      email: agent.email,
      phone: agent.phone,
      role: agent.role,
      color: agent.color || '#14382F',
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      alert('Veuillez renseigner le nom complet.');
      return;
    }

    if (editingAgent) {
      onUpdateAgent({
        ...editingAgent,
        name: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        role: formData.role,
        color: formData.color,
      });
    } else {
      const newAgent: Agent = {
        id: `agent_${Date.now().toString(36)}`,
        name: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        role: formData.role,
        color: formData.color,
      };
      onAddAgent(newAgent);
    }

    setIsModalOpen(false);
  };

  const validAgents = useMemo(() => agents.filter((a) => !isFictionalAgent(a)), [agents]);

  const filteredAgents = validAgents.filter((a) => {
    if (roleFilter !== 'all' && a.role !== roleFilter) return false;
    return true;
  });

  // Calculate appointment count per agent
  const getAppointmentCount = (agentId: string) => {
    return appointments.filter((a) => a.agent_id === agentId).length;
  };

  const handleConfirmDeleteAgent = () => {
    if (agentToDelete) {
      onDeleteAgent(agentToDelete.id);
      setAgentToDelete(null);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto">
      {/* Top Banner */}
      <div className="bg-white border border-[#DBE4DC] rounded-2xl p-6 sm:p-8 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#5E7368] block">
            Gestion des Utilisateurs & Droits
          </span>
          <h1 className="font-editorial text-2xl sm:text-3xl font-bold text-[#14382F] mt-0.5">
            Équipe Commerciale & Administrateurs
          </h1>
          <p className="text-sm text-[#5E7368] mt-1 max-w-2xl">
            Gérez les administrateurs et les commerciaux terrain. Ces profils sont synchronisés avec l'onglet <strong className="text-slate-800">« Utilisateurs »</strong> de votre Google Sheet.
          </p>
        </div>

        {activeUser.role === 'administrateur' ? (
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
          >
            <UserPlus className="w-4 h-4 text-[#C9882B]" />
            <span>Ajouter un commercial ou admin</span>
          </button>
        ) : (
          <div className="text-xs bg-slate-100 text-slate-700 px-3 py-2 rounded-xl border border-slate-200 font-medium">
            Annuaire collaborateur (Accès en consultation)
          </div>
        )}
      </div>

      {/* Role Filter Tabs */}
      <div className="flex items-center gap-2 bg-white border border-[#DBE4DC] p-1.5 rounded-xl w-fit text-xs font-semibold">
        <button
          onClick={() => setRoleFilter('all')}
          className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
            roleFilter === 'all'
              ? 'bg-[#14382F] text-white shadow-xs'
              : 'text-[#5E7368] hover:text-[#14382F]'
          }`}
        >
          Tous les membres ({validAgents.length})
        </button>
        <button
          onClick={() => setRoleFilter('administrateur')}
          className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
            roleFilter === 'administrateur'
              ? 'bg-[#14382F] text-white shadow-xs'
              : 'text-[#5E7368] hover:text-[#14382F]'
          }`}
        >
          Administrateurs ({validAgents.filter((a) => a.role === 'administrateur').length})
        </button>
        <button
          onClick={() => setRoleFilter('agent')}
          className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
            roleFilter === 'agent'
              ? 'bg-[#14382F] text-white shadow-xs'
              : 'text-[#5E7368] hover:text-[#14382F]'
          }`}
        >
          Commerciaux terrain ({validAgents.filter((a) => a.role === 'agent').length})
        </button>
      </div>

      {/* Team Cards Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredAgents.map((agent) => {
          const count = getAppointmentCount(agent.id);
          const isActive = activeUser.id === agent.id;
          const isSophie = agent.name.toLowerCase().includes('sophie vaillant');

          return (
            <div
              key={agent.id}
              className={`bg-white border rounded-2xl p-6 shadow-sm transition-all flex flex-col justify-between ${
                isActive ? 'border-[#14382F] ring-2 ring-[#14382F]/20' : 'border-[#DBE4DC] hover:border-[#14382F]/40'
              }`}
            >
              <div>
                {/* Header card with Role badge */}
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center text-white font-bold font-editorial text-base shadow-xs"
                      style={{ backgroundColor: agent.color || '#14382F' }}
                    >
                      {agent.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-[#182B24] flex items-center gap-1.5">
                        {agent.name}
                        {isSophie && (
                          <span className="text-[10px] bg-[#C9882B]/20 text-[#C9882B] px-1.5 py-0.2 rounded font-semibold">
                            Directrice
                          </span>
                        )}
                      </h3>
                      <span className="text-xs text-[#5E7368] block">
                        {agent.role === 'administrateur' ? 'Administrateur' : 'Commercial Terrain'}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 ${
                      agent.role === 'administrateur'
                        ? 'bg-amber-100 text-amber-900 border border-amber-200'
                        : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                    }`}
                  >
                    {agent.role === 'administrateur' ? (
                      <Shield className="w-3 h-3 text-[#C9882B]" />
                    ) : (
                      <User className="w-3 h-3 text-emerald-700" />
                    )}
                    {agent.role === 'administrateur' ? 'Admin' : 'Commercial'}
                  </span>
                </div>

                {/* Details */}
                <div className="space-y-2 text-xs text-[#5E7368] py-3 border-y border-[#DBE4DC]/70">
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-[#C9882B] shrink-0" />
                    <span className="text-[#182B24] font-medium">{agent.phone || 'Non renseigné'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-[#5E7368] shrink-0" />
                    <span className="truncate">{agent.email || 'Non renseigné'}</span>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <Zap className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>
                      Dossiers attribués : <strong className="text-[#14382F]">{count}</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="flex items-center justify-between pt-4 mt-4">
                <div className="flex items-center gap-1.5">
                  {activeUser.role === 'administrateur' && (
                    <>
                      <button
                        onClick={() => handleOpenEdit(agent)}
                        className="p-1.5 text-slate-500 hover:text-[#14382F] hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                        title="Modifier"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>

                      {!isSophie && (
                        <button
                          onClick={() => setAgentToDelete(agent)}
                          className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                          title="Supprimer ce collaborateur"
                          aria-label={`Supprimer ${agent.name}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </>
                  )}
                </div>

                <button
                  onClick={() => onSwitchUser(agent)}
                  disabled={isActive}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-[#14382F] text-white shadow-xs'
                      : 'border border-[#B8CABE] text-[#14382F] hover:bg-slate-50'
                  }`}
                >
                  {isActive ? (
                    <>
                      <UserCheck className="w-3.5 h-3.5 text-[#C9882B]" />
                      <span>Actif</span>
                    </>
                  ) : (
                    <span>Se connecter en tant que</span>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full border border-[#DBE4DC] shadow-2xl p-6 sm:p-7">
            <div className="flex items-center justify-between border-b border-[#DBE4DC] pb-4 mb-5">
              <h3 className="font-editorial text-xl font-bold text-[#14382F]">
                {editingAgent ? 'Modifier le membre' : 'Ajouter un membre d’équipe'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Nom et prénom complet *
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: Alexandre Dupuis"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Rôle & Permissions *
                </label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                >
                  <option value="agent">Commercial Terrain (voit et gère ses RDV)</option>
                  <option value="administrateur">Administrateur (accès complet à tous les RDV et à la config)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Adresse email professionnelle
                </label>
                <input
                  type="email"
                  placeholder="ex: commercial@t2a-ecohabitat.fr"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1">
                  Numéro de téléphone
                </label>
                <input
                  type="tel"
                  placeholder="ex: 06 11 22 33 44"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-[#FAFBF8] border border-[#B8CABE] rounded-lg px-3 py-2 text-xs text-[#182B24] focus:outline-none focus:ring-2 focus:ring-[#14382F]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#182B24] mb-1.5">
                  Couleur d'identification (sur l'agenda)
                </label>
                <div className="flex items-center gap-2">
                  {COLOR_PALETTE.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setFormData({ ...formData, color: c })}
                      className={`w-7 h-7 rounded-lg transition-transform ${
                        formData.color === c ? 'scale-115 ring-2 ring-offset-2 ring-[#14382F]' : ''
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#DBE4DC]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-[#B8CABE] text-[#14382F] rounded-lg text-xs font-semibold"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#14382F] hover:bg-[#0D2620] text-white rounded-lg text-xs font-bold shadow-sm"
                >
                  {editingAgent ? 'Sauvegarder' : 'Ajouter le membre'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Safe In-App Agent Delete Confirmation Modal */}
      {agentToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full border border-red-200 shadow-2xl p-6">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-red-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-editorial text-lg font-bold text-[#14382F]">
                  Supprimer ce collaborateur ?
                </h3>
                <p className="text-xs text-[#5E7368] mt-1 leading-relaxed">
                  Êtes-vous sûr de vouloir supprimer le compte de{' '}
                  <strong className="text-slate-900">{agentToDelete.name}</strong> ({agentToDelete.role === 'administrateur' ? 'Administrateur' : 'Commercial'}) ?
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-[#DBE4DC]">
              <button
                type="button"
                onClick={() => setAgentToDelete(null)}
                className="px-4 py-2 border border-[#B8CABE] hover:bg-slate-50 text-[#14382F] rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteAgent}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Oui, supprimer</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
