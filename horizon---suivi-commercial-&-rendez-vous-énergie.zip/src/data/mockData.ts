import { Agent, Appointment } from '../types';

export const INITIAL_AGENTS: Agent[] = [
  {
    id: 'agent_sophie',
    name: 'Sophie Vaillant',
    email: 'sophie.vaillant@t2a-ecohabitat.fr',
    role: 'administrateur',
    phone: '06 20 30 40 50',
    color: '#14382F', // Forest green
  },
];

// Production database initialized with zero mock appointments
export const INITIAL_APPOINTMENTS: Appointment[] = [];
