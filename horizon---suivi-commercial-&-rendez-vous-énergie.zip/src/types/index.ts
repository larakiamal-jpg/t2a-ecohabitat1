export type ProjectType =
  | 'panneaux photovoltaïques'
  | 'pompe à chaleur'
  | 'système solaire combiné'
  | 'rénovation globale'
  | 'autre';

export type AppointmentStatus =
  | 'à confirmer'
  | 'confirmé'
  | 'réalisé'
  | 'reporté'
  | 'annulé';

export type UserRole = 'administrateur' | 'agent';

export interface Agent {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone: string;
  color: string;
}

export interface Appointment {
  id: string;
  prospect_name: string;
  phone: string;
  email: string;
  postal_code: string;
  city: string;
  address?: string;
  project_type: ProjectType;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  status: AppointmentStatus;
  agent_id: string;
  comment: string;
  estimated_power?: string; // e.g. 6 kWc
  current_heating?: string; // e.g. Fioul, Gaz, Électrique
  roof_orientation?: string; // e.g. Sud, Est-Ouest
  created_at: string;
  updated_at: string;
  source?: string;
}

export interface SyncConfig {
  exec_url: string;
  sheets_id: string;
  client_id: string;
  auto_sync: boolean;
  last_sync: string | null;
  sync_status: 'idle' | 'syncing' | 'success' | 'error';
  last_error: string | null;
}

export interface DiagnosticResult {
  step: string;
  success: boolean;
  timestamp: string;
  httpStatus?: number;
  urlObserved?: string;
  details: string;
  dataSnippet?: string;
}
