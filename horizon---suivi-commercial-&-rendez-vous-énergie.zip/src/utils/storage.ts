import { Agent, Appointment, DiagnosticResult, SyncConfig } from '../types';
import { INITIAL_AGENTS, INITIAL_APPOINTMENTS } from '../data/mockData';

const APPOINTMENTS_KEY = 'horizon_appointments_v3';
const AGENTS_KEY = 'horizon_agents_v3';
const SYNC_CONFIG_KEY = 'horizon_sync_config_v3';
const CURRENT_USER_KEY = 'horizon_active_user_v3';

export const USER_APPS_SCRIPT_URL =
  'https://script.google.com/macros/s/AKfycby9YmDbQA484YjYlJz1ziIHDXCDXEDk7sepzQIg8hBQsqh4Hvtgey-5RgcrvWReUSla1g/exec';

export const DEFAULT_SYNC_CONFIG: SyncConfig = {
  exec_url: USER_APPS_SCRIPT_URL,
  sheets_id: '1VWIJpeAqeePtF2NuSTxzVhnxZhzNwqZM-RxjK2UOl1U',
  client_id: '',
  auto_sync: false,
  last_sync: null,
  sync_status: 'idle',
  last_error: null,
};

const LEGACY_STORAGE_KEYS = [
  'horizon_agents',
  'horizon_agents_v1',
  'horizon_agents_v2',
  'horizon_appointments',
  'horizon_appointments_v1',
  'horizon_appointments_v2',
  'horizon_active_user',
  'horizon_active_user_v1',
  'horizon_active_user_v2',
  'horizon_sync_config_v1',
  'horizon-appointment-config',
  'agents',
  'appointments',
];

export function purgeLegacyStorage(): void {
  try {
    for (const key of LEGACY_STORAGE_KEYS) {
      localStorage.removeItem(key);
    }
  } catch (err) {
    console.error('Error clearing legacy storage', err);
  }
}

// Immediately purge on module load
if (typeof window !== 'undefined' && window.localStorage) {
  purgeLegacyStorage();
}

export function isFictionalAgent(a: Agent | Partial<Agent> | null | undefined): boolean {
  if (!a) return true;
  const name = (a.name || '').toLowerCase().trim();

  // Sophie Vaillant is strictly the only valid administrator
  if (name.includes('sophie') && name.includes('vaillant')) {
    return false;
  }

  // Known legacy mock IDs
  if (a.id && /^(agent_[1-9]|agent_1[0-9]|agent_thomas|agent_sarah|agent_marc|agent_julie)$/i.test(a.id)) {
    return true;
  }

  // Fictional agent names / surnames to permanently eliminate
  const fictionalTokens = [
    'thomas',
    'dubois',
    'sarah',
    'benali',
    'marc',
    'lefevre',
    'lefèvre',
    'julie',
    'martin',
  ];

  if (fictionalTokens.some((token) => name.includes(token))) {
    return true;
  }

  return false;
}

export function loadAppointments(): Appointment[] {
  try {
    purgeLegacyStorage();
    const raw = localStorage.getItem(APPOINTMENTS_KEY);
    if (!raw) {
      saveAppointments([]);
      return [];
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    // Purge mock demo appointments
    const realAppointments = parsed.filter(
      (a: Appointment) => !/^rdv-10[1-9]$/.test(a.id)
    );
    if (realAppointments.length !== parsed.length) {
      saveAppointments(realAppointments);
    }
    return realAppointments;
  } catch (err) {
    console.error('Error loading appointments from localStorage', err);
    return [];
  }
}

export function saveAppointments(appointments: Appointment[]): void {
  try {
    localStorage.setItem(APPOINTMENTS_KEY, JSON.stringify(appointments));
  } catch (err) {
    console.error('Error saving appointments', err);
  }
}

export function loadAgents(): Agent[] {
  try {
    purgeLegacyStorage();
    const raw = localStorage.getItem(AGENTS_KEY);
    if (!raw) {
      saveAgents(INITIAL_AGENTS);
      return INITIAL_AGENTS;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      saveAgents(INITIAL_AGENTS);
      return INITIAL_AGENTS;
    }

    // Strictly purge any fictional demo sales reps by ID or Name
    const realAgents = parsed.filter((a: Agent) => !isFictionalAgent(a));

    // Ensure Sophie Vaillant is always present
    const hasSophie = realAgents.some((a: Agent) => a.name.toLowerCase().includes('sophie vaillant'));
    const finalAgents = hasSophie ? realAgents : [INITIAL_AGENTS[0], ...realAgents];

    saveAgents(finalAgents);
    return finalAgents;
  } catch (err) {
    console.error('Error loading agents', err);
    return INITIAL_AGENTS;
  }
}

export function saveAgents(agents: Agent[]): void {
  try {
    const cleaned = agents.filter((a) => !isFictionalAgent(a));
    const hasSophie = cleaned.some((a) => a.name.toLowerCase().includes('sophie vaillant'));
    const finalAgents = hasSophie ? cleaned : [INITIAL_AGENTS[0], ...cleaned];
    localStorage.setItem(AGENTS_KEY, JSON.stringify(finalAgents));
  } catch (err) {
    console.error('Error saving agents', err);
  }
}

export function loadSyncConfig(): SyncConfig {
  try {
    const raw = localStorage.getItem(SYNC_CONFIG_KEY);
    if (!raw) {
      saveSyncConfig(DEFAULT_SYNC_CONFIG);
      return DEFAULT_SYNC_CONFIG;
    }
    const parsed = JSON.parse(raw);
    if (!parsed.exec_url || parsed.exec_url.includes('AKfycbydJCPzEvTkh')) {
      parsed.exec_url = USER_APPS_SCRIPT_URL;
      saveSyncConfig({ ...DEFAULT_SYNC_CONFIG, ...parsed });
    }
    return { ...DEFAULT_SYNC_CONFIG, ...parsed };
  } catch (err) {
    console.error('Error loading sync config', err);
    return DEFAULT_SYNC_CONFIG;
  }
}

export function saveSyncConfig(config: SyncConfig): void {
  try {
    localStorage.setItem(SYNC_CONFIG_KEY, JSON.stringify(config));
  } catch (err) {
    console.error('Error saving sync config', err);
  }
}

export function loadActiveUser(agents: Agent[]): Agent {
  try {
    const id = localStorage.getItem(CURRENT_USER_KEY);
    const validAgents = agents.filter((a) => !isFictionalAgent(a));
    const found = validAgents.find((a) => a.id === id);
    if (found) return found;
    const sophie = validAgents.find((a) => a.name.toLowerCase().includes('sophie vaillant'));
    return sophie || validAgents[0] || INITIAL_AGENTS[0];
  } catch {
    return INITIAL_AGENTS[0];
  }
}

export function saveActiveUser(user: Agent): void {
  try {
    localStorage.setItem(CURRENT_USER_KEY, user.id);
  } catch (err) {
    console.error('Error saving active user', err);
  }
}

// Check duplicates
export function findPotentialDuplicates(
  newAppointment: Partial<Appointment>,
  existingList: Appointment[],
  currentEditId?: string
): { isDuplicate: boolean; reasons: string[]; matches: Appointment[] } {
  const matches: Appointment[] = [];
  const reasons: string[] = [];

  const cleanPhone = (p?: string) => (p || '').replace(/\D/g, '');
  const targetPhone = cleanPhone(newAppointment.phone);

  for (const item of existingList) {
    if (currentEditId && item.id === currentEditId) continue;

    // Check same phone
    if (targetPhone && targetPhone.length >= 8 && cleanPhone(item.phone) === targetPhone) {
      matches.push(item);
      reasons.push(`Numéro de téléphone identique pour le prospect "${item.prospect_name}".`);
      continue;
    }

    // Check same agent at the same time slot (+/- 45 mins)
    if (
      newAppointment.agent_id &&
      item.agent_id === newAppointment.agent_id &&
      newAppointment.date &&
      item.date === newAppointment.date &&
      newAppointment.time &&
      item.time
    ) {
      const [h1, m1] = newAppointment.time.split(':').map(Number);
      const [h2, m2] = item.time.split(':').map(Number);
      const diffMinutes = Math.abs((h1 * 60 + m1) - (h2 * 60 + m2));
      if (diffMinutes < 45) {
        matches.push(item);
        reasons.push(
          `L’agent est déjà mobilisé à ${item.time} avec "${item.prospect_name}" (${item.city}).`
        );
      }
    }
  }

  return {
    isDuplicate: matches.length > 0,
    reasons,
    matches,
  };
}

// Export appointments as CSV
export function exportToCSV(appointments: Appointment[], agents: Agent[]): void {
  const headers = [
    'ID',
    'Prospect',
    'Téléphone',
    'Email',
    'Code Postal',
    'Ville',
    'Adresse',
    'Type Projet',
    'Date',
    'Heure',
    'Statut',
    'Agent Responsable',
    'Chauffage Actuel',
    'Puissance Estimée',
    'Commentaire',
  ];

  const agentMap = new Map(agents.map((a) => [a.id, a.name]));

  const rows = appointments.map((a) => [
    a.id,
    `"${(a.prospect_name || '').replace(/"/g, '""')}"`,
    `"${a.phone || ''}"`,
    `"${a.email || ''}"`,
    `"${a.postal_code || ''}"`,
    `"${(a.city || '').replace(/"/g, '""')}"`,
    `"${(a.address || '').replace(/"/g, '""')}"`,
    `"${a.project_type || ''}"`,
    a.date,
    a.time,
    a.status,
    `"${agentMap.get(a.agent_id) || 'Inconnu'}"`,
    `"${a.current_heating || ''}"`,
    `"${a.estimated_power || ''}"`,
    `"${(a.comment || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = '\uFEFF' + [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute(
    'download',
    `t2a-ecohabitat-rdv-${new Date().toISOString().split('T')[0]}.csv`
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Extracts a Google Spreadsheet ID from either a full URL or a raw ID string.
 */
export function extractSpreadsheetId(input: string): string {
  if (!input) return '';
  const trimmed = input.trim();
  const match = trimmed.match(/\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) {
    return match[1];
  }
  return trimmed.split('?')[0].split('#')[0];
}

/**
 * Generates the direct edit link to the Google Sheet.
 */
export function getGoogleSheetUrl(sheetsId: string): string {
  if (!sheetsId) return 'https://docs.google.com/spreadsheets';
  const cleanId = extractSpreadsheetId(sheetsId);
  return `https://docs.google.com/spreadsheets/d/${cleanId}/edit`;
}

/**
 * Parses and validates Google Apps Script responses, detecting permission denials.
 */
export async function parseAppsScriptResponse(res: Response): Promise<{
  ok: boolean;
  error?: string;
  isPermissionError?: boolean;
  data?: any;
}> {
  let text = '';
  try {
    text = await res.text();
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Erreur réseau';
    return { ok: false, error: `Erreur de lecture réseau : ${msg}` };
  }

  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {
    // If not json, might be Google Drive error HTML page
    if (text.includes('permission') || text.includes('Unable to open the file') || text.includes('drive.google.com')) {
      return {
        ok: false,
        isPermissionError: true,
        error: "Google refuse l'accès au classeur. Le Google Sheet doit être partagé en mode Éditeur.",
      };
    }
    return {
      ok: false,
      error: `Réponse serveur non reconnue : ${text.slice(0, 160)}`,
    };
  }

  if (json && json.ok === false) {
    const rawError = String(json.error || '');
    const isPerm =
      rawError.toLowerCase().includes('permission') ||
      rawError.toLowerCase().includes('requested document') ||
      rawError.toLowerCase().includes('permission_denied');

    const friendlyError = isPerm
      ? "Permission refusée par Google : Le script Apps Script n'a pas les droits pour modifier ce Google Sheet. Veuillez ouvrir votre Google Sheet, cliquer sur 'Partager' en haut à droite, et choisir 'Tous les utilisateurs disposant du lien : Éditeur'."
      : json.error || 'Erreur retournée par Google Apps Script';

    return {
      ok: false,
      isPermissionError: isPerm,
      error: friendlyError,
    };
  }

  if (!res.ok) {
    return {
      ok: false,
      error: `Erreur HTTP ${res.status}`,
    };
  }

  return { ok: true, data: json?.data };
}

export const CRM_COLUMNS = [
  'stable_id',
  'owner_id',
  'type',
  'name',
  'first_name',
  'company',
  'job_title',
  'phone',
  'email',
  'address',
  'postal_code',
  'city',
  'contact_type',
  'category',
  'source',
  'status',
  'pipeline_stage',
  'housing_type',
  'notes',
  'estimated_value',
  'rdv_date',
  'rdv_agent_setter',
  'rdv_agent_commercial',
  'rdv_status',
  'rdv_comment',
  'next_action',
  'follow_up_date',
  'last_contact_date',
  'created_at',
  'updated_at',
  'is_example',
  'metadata',
] as const;

/**
 * Maps an internal Appointment into the 32 columns of the user's CRM Sheet.
 */
export function mapAppointmentToCrmValues(
  appointment: Appointment,
  agentName: string = 'Sophie Vaillant'
): any[] {
  const rawName = (appointment.prospect_name || '').trim();
  const nameParts = rawName.split(/\s+/);
  const firstName = nameParts.length > 1 ? nameParts[0] : '';
  const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : nameParts[0] || '';

  const notes = [
    appointment.comment,
    appointment.current_heating ? `Chauffage: ${appointment.current_heating}` : '',
    appointment.roof_orientation ? `Toiture: ${appointment.roof_orientation}` : '',
    appointment.estimated_power ? `Puissance: ${appointment.estimated_power}` : '',
  ]
    .filter(Boolean)
    .join(' | ');

  const rdvDateTime = `${appointment.date || ''} ${appointment.time || ''}`.trim();
  const pipeline =
    appointment.status === 'confirmé'
      ? 'Rendez-vous planifié'
      : appointment.status === 'réalisé'
      ? 'Rendez-vous effectué'
      : 'Rendez-vous pris';

  return [
    appointment.id,                                      // 1. stable_id
    appointment.agent_id || 'agent_sophie',             // 2. owner_id
    'particulier',                                      // 3. type
    lastName,                                           // 4. name
    firstName,                                          // 5. first_name
    '',                                                 // 6. company
    '',                                                 // 7. job_title
    appointment.phone || '',                            // 8. phone
    appointment.email || '',                            // 9. email
    appointment.address || '',                          // 10. address
    appointment.postal_code || '',                      // 11. postal_code
    appointment.city || '',                             // 12. city
    'Prospect',                                         // 13. contact_type
    appointment.project_type || 'panneaux photovoltaïques', // 14. category
    appointment.source || 'T2A ECOHABITAT',             // 15. source
    appointment.status || 'à confirmer',                // 16. status
    pipeline,                                           // 17. pipeline_stage
    'Maison individuelle',                              // 18. housing_type
    notes,                                              // 19. notes
    appointment.estimated_power || '',                  // 20. estimated_value
    rdvDateTime,                                        // 21. rdv_date
    agentName,                                          // 22. rdv_agent_setter
    agentName,                                          // 23. rdv_agent_commercial
    appointment.status || 'à confirmer',                // 24. rdv_status
    appointment.comment || '',                          // 25. rdv_comment
    'Visite technique / Devis',                         // 26. next_action
    appointment.date || '',                             // 27. follow_up_date
    (appointment.created_at || new Date().toISOString()).split('T')[0], // 28. last_contact_date
    appointment.created_at || new Date().toISOString(), // 29. created_at
    appointment.updated_at || new Date().toISOString(), // 30. updated_at
    false,                                              // 31. is_example
    JSON.stringify({                                    // 32. metadata
      heating: appointment.current_heating || null,
      power: appointment.estimated_power || null,
      roof: appointment.roof_orientation || null,
    }),
  ];
}

/**
 * Pushes a single appointment to the connected Google Sheet.
 */
export async function pushAppointmentToGoogleSheet(
  appointment: Appointment,
  config: SyncConfig,
  agentName?: string
): Promise<{ success: boolean; error?: string; isPermissionError?: boolean }> {
  if (!config.exec_url) {
    return {
      success: false,
      error: "URL du script Google Apps Script non configurée.",
    };
  }

  const crmValues = mapAppointmentToCrmValues(appointment, agentName);

  try {
    const res = await fetch(config.exec_url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      credentials: 'omit',
      body: JSON.stringify({
        action: 'createAppointment',
        sheets_id: config.sheets_id,
        target_sheet: 'CRM',
        payload: {
          ...appointment,
          sheets_id: config.sheets_id,
          target_sheet: 'CRM',
          crm_headers: CRM_COLUMNS,
          crm_values: crmValues,
        },
      }),
    });

    const parsed = await parseAppsScriptResponse(res);
    if (!parsed.ok) {
      return {
        success: false,
        error: parsed.error,
        isPermissionError: parsed.isPermissionError,
      };
    }

    return { success: true };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Erreur inconnue';
    return { success: false, error: `Erreur de connexion : ${errorMsg}` };
  }
}

/**
 * Pushes all appointments to the connected Google Sheet.
 */
export async function pushAllAppointmentsToGoogleSheet(
  appointments: Appointment[],
  config: SyncConfig
): Promise<{ success: boolean; count: number; error?: string; isPermissionError?: boolean }> {
  if (!config.exec_url) {
    return {
      success: false,
      count: 0,
      error: "URL du script Google Apps Script non configurée.",
    };
  }

  if (appointments.length === 0) {
    return {
      success: true,
      count: 0,
      error: "Aucun rendez-vous à synchroniser.",
    };
  }

  const enrichedAppointments = appointments.map((item) => ({
    ...item,
    crm_headers: CRM_COLUMNS,
    crm_values: mapAppointmentToCrmValues(item),
  }));

  // First try batch if supported
  try {
    const batchRes = await fetch(config.exec_url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      credentials: 'omit',
      body: JSON.stringify({
        action: 'batchCreateAppointments',
        sheets_id: config.sheets_id,
        target_sheet: 'CRM',
        payload: {
          appointments: enrichedAppointments,
          sheets_id: config.sheets_id,
          target_sheet: 'CRM',
        },
      }),
    });

    const batchParsed = await parseAppsScriptResponse(batchRes);
    if (batchParsed.ok) {
      return { success: true, count: appointments.length };
    }

    if (batchParsed.isPermissionError) {
      return {
        success: false,
        count: 0,
        error: batchParsed.error,
        isPermissionError: true,
      };
    }
  } catch {
    // If batch fails, fallback to sequential
  }

  // Sequential push fallback
  let count = 0;
  for (const item of appointments) {
    const res = await fetch(config.exec_url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      credentials: 'omit',
      body: JSON.stringify({
        action: 'createAppointment',
        sheets_id: config.sheets_id,
        target_sheet: 'CRM',
        payload: {
          ...item,
          sheets_id: config.sheets_id,
          target_sheet: 'CRM',
          crm_headers: CRM_COLUMNS,
          crm_values: mapAppointmentToCrmValues(item),
        },
      }),
    });

    const parsed = await parseAppsScriptResponse(res);
    if (!parsed.ok) {
      return {
        success: false,
        count,
        error: parsed.error,
        isPermissionError: parsed.isPermissionError,
      };
    }
    count++;
  }

  return { success: true, count };
}

// Complete test Apps Script connection including real Sheet access
export async function testAppsScriptConnection(
  execUrl: string,
  sheetsId?: string
): Promise<DiagnosticResult[]> {
  const results: DiagnosticResult[] = [];
  const start = Date.now();

  if (!execUrl || !execUrl.startsWith('https://')) {
    results.push({
      step: 'Validation URL',
      success: false,
      timestamp: new Date().toLocaleTimeString('fr-FR'),
      details: 'URL invalide : elle doit commencer par https:// et pointer vers votre déploiement Google Apps Script.',
    });
    return results;
  }

  // Step 1: Format validation
  const isExec = execUrl.includes('/exec');
  results.push({
    step: 'Structure de l’endpoint',
    success: isExec,
    timestamp: new Date().toLocaleTimeString('fr-FR'),
    details: isExec
      ? 'URL conforme : déploiement Apps Script en mode /exec actif.'
      : 'Attention : l’URL ne se termine pas par /exec.',
  });

  // Step 2: GET ping (Service online check)
  let serviceOnline = false;
  try {
    const res = await fetch(execUrl, {
      method: 'GET',
      credentials: 'omit',
    });

    const elapsed = Date.now() - start;
    const contentType = res.headers.get('content-type') || 'inconnu';
    const text = await res.text();

    let isJson = false;
    let preview = text.slice(0, 300);
    try {
      const parsed = JSON.parse(text);
      isJson = true;
      preview = JSON.stringify(parsed);
      if (parsed.ok) serviceOnline = true;
    } catch {
      // not json
    }

    results.push({
      step: 'Test de lisibilité réseau (GET)',
      success: res.ok,
      httpStatus: res.status,
      timestamp: new Date().toLocaleTimeString('fr-FR'),
      urlObserved: res.url,
      details: `Réponse reçue en ${elapsed}ms (HTTP ${res.status}). Type : ${contentType}.${
        res.redirected ? ' Redirection Google suivie.' : ''
      }`,
      dataSnippet: preview,
    });

    results.push({
      step: 'Format de réponse JSON',
      success: isJson,
      timestamp: new Date().toLocaleTimeString('fr-FR'),
      details: isJson
        ? 'Réponse JSON valide retournée par Apps Script.'
        : 'La réponse reçue n’est pas du JSON.',
    });

    if (isJson) {
      try {
        const parsed = JSON.parse(text);
        if (parsed.version && !parsed.version.startsWith('3.')) {
          results.push({
            step: 'Version du Script Apps Script',
            success: false,
            timestamp: new Date().toLocaleTimeString('fr-FR'),
            details: `🚨 DÉCALAGE DES COLONNES EXPLIQUÉ : Votre Google Apps Script exécute l'ancienne version ${parsed.version}. Pour corriger le décalage, collez le nouveau script (v3.1.0) dans Google Apps Script et déployez une "Nouvelle version".`,
            dataSnippet: `Version active: ${parsed.version} | Version requise: 3.1.0 (Auto-Map CRM)`,
          });
        } else if (parsed.version) {
          results.push({
            step: 'Version du Script Apps Script',
            success: true,
            timestamp: new Date().toLocaleTimeString('fr-FR'),
            details: `Script à jour : Version ${parsed.version} avec alignement dynamique des 32 colonnes CRM.`,
          });
        }
      } catch {}
    }
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Erreur inconnue';
    results.push({
      step: 'Test de lisibilité réseau (GET)',
      success: false,
      timestamp: new Date().toLocaleTimeString('fr-FR'),
      details: `Échec réseau ou blocage : ${errorMsg}.`,
    });
  }

  // Step 3: Real test of Google Sheet Access & Write Permissions (POST)
  if (serviceOnline) {
    const targetSheetId = extractSpreadsheetId(sheetsId || '1VWIJpeAqeePtF2NuSTxzVhnxZhzNwqZM-RxjK2UOl1U');
    try {
      const postRes = await fetch(execUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        credentials: 'omit',
        body: JSON.stringify({
          action: 'ping',
          sheets_id: targetSheetId,
        }),
      });

      const parsed = await parseAppsScriptResponse(postRes);
      if (parsed.ok) {
        results.push({
          step: 'Accès en écriture au Google Sheet',
          success: true,
          timestamp: new Date().toLocaleTimeString('fr-FR'),
          details: `Connexion et droits d'accès au classeur (${targetSheetId}) validés avec succès !`,
        });
      } else {
        results.push({
          step: 'Accès en écriture au Google Sheet',
          success: false,
          timestamp: new Date().toLocaleTimeString('fr-FR'),
          details: parsed.isPermissionError
            ? `🚨 PERMISSION REFUSÉE PAR GOOGLE : Google bloque l'accès au classeur (ID: ${targetSheetId}).\n👉 Solution : Ouvrez votre Google Sheet, cliquez sur 'Partager' en haut à droite, puis passez 'Accès général' à 'Tous les utilisateurs disposant du lien' en tant qu'Éditeur.`
            : `Erreur d'accès : ${parsed.error}`,
          dataSnippet: parsed.error,
        });
      }
    } catch (postErr: unknown) {
      const postMsg = postErr instanceof Error ? postErr.message : 'Erreur';
      results.push({
        step: 'Accès en écriture au Google Sheet',
        success: false,
        timestamp: new Date().toLocaleTimeString('fr-FR'),
        details: `Impossible de tester l'accès au Sheet : ${postMsg}`,
      });
    }
  }

  return results;
}
